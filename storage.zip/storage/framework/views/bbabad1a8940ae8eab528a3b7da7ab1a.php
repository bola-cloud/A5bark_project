<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Courses'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('courses.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('courses_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.courses.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('courses.Name'); ?></th>
                        <th><?php echo app('translator')->get('courses.Trainer'); ?></th>
                        <th><?php echo app('translator')->get('courses.Categories'); ?></th>
                        <th><?php echo app('translator')->get('courses.Price'); ?></th>
                        <th><?php echo app('translator')->get('courses.Subscription_Type'); ?></th>
                        <th><?php echo app('translator')->get('courses.Subscription_Long'); ?></th>
                        <th><?php echo app('translator')->get('courses.Subscriptions'); ?></th>
                        <th><?php echo app('translator')->get('courses.Trainer Ratio'); ?></th>
                        <th><?php echo app('translator')->get('courses.Created At'); ?></th>
                        <th><?php echo app('translator')->get('courses.Media'); ?></th>
                        <th><?php echo app('translator')->get('courses.Top Course'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    <?php if($permissions == 'admin' || in_array('courses_add', $permissions)): ?>
        <?php echo $__env->make('admin.courses.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('courses_show', $permissions)): ?>
        <?php echo $__env->make('admin.courses.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('courses_edit', $permissions)): ?>
        <?php echo $__env->make('admin.courses.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('admin.courses.incs._media', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('document').ready(function () {
        let lang = "<?php echo e($lang); ?>";

        const objects_dynamic_table = new DynamicTable(
            {
                index_route   : "<?php echo e(route('admin.courses.index')); ?>",
                store_route   : "<?php echo e(route('admin.courses.store')); ?>",
                show_route    : "<?php echo e(route('admin.courses.index')); ?>",
                update_route  : "<?php echo e(route('admin.courses.index')); ?>",
                destroy_route : "<?php echo e(route('admin.courses.index')); ?>",
            },
            '#dataTable',
            {
                success_el : '#successAlert',
                danger_el  : '#dangerAlert',
                warning_el : '#warningAlert'
            },
            {
                table_id        : '#dataTable',
                toggle_btn      : '.toggle-btn',
                create_obj_btn  : '.create-object',
                update_obj_btn  : '.update-object',
                fields_list     : [
                    'id',
                    'ar_title', 'en_title',
                    'ar_description', 'en_description',
                    'price', 'trainer_ratio', 'trainer_id', 
                    'categories', 'subscription_type', 'subscription_long', 'image'
                ],
                imgs_fields     : ['image']
            },
            [
                { data: 'id',            name: 'id' },
                { data: 'title',         name: 'title' },
                { data: 'trainer',       name: 'trainer' },
                { data: 'categories',    name: 'categories' },
                { data: 'price',         name: 'price' },
                { data: 'subscription_type', name: 'subscription_type' },
                { data: 'subscription_long', name: 'subscription_long' },
                { data: 'subscriptions_count',  name: 'subscriptions_count' },
                { data: 'trainer_ratio', name: 'trainer_ratio' },
                { data: 'created_at',    name: 'created_at' },
                { data: 'media_btn',     name: 'media_btn' },
                { data: 'top_course',    name: 'top_course' },
                { data: 'activation',    name: 'activation' },
                { data: 'actions',       name: 'actions' },
            ],
            function (d) {
                if ($('#s-name').length)
                d.name = $('#s-name').val(); 

                if ($('#s-trainers').length)
                d.trainers = $('#s-trainers').val();  
                
                if ($('#s-categories').length)
                d.categories = $('#s-categories').val();  
                
                if ($('#s-is_active').length)
                d.is_active = $('#s-is_active').val(); 

            }
        );

        objects_dynamic_table.validateData = (data, prefix = '') => {
            // inite validation flag
            let is_valide = true;

            // clear old validation session
            $('.err-msg').slideUp(500);

            if (data.get('ar_title') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.ar_title is required"); ?>';
                $(`#${prefix}ar_titleErr`).text(err_msg);
                $(`#${prefix}ar_titleErr`).slideDown(500);
            }

            if (data.get('en_title') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.en_title is required"); ?>';
                $(`#${prefix}en_titleErr`).text(err_msg);
                $(`#${prefix}en_titleErr`).slideDown(500);
            }

            if (data.get('ar_description') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.ar_description is required"); ?>';
                $(`#${prefix}ar_descriptionErr`).text(err_msg);
                $(`#${prefix}ar_descriptionErr`).slideDown(500);
            }

            if (data.get('en_description') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.en_description is required"); ?>';
                $(`#${prefix}en_descriptionErr`).text(err_msg);
                $(`#${prefix}en_descriptionErr`).slideDown(500);
            }

            if (['', 'null', null, 'undefined'].includes(data.get('categories'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.categories is required"); ?>';
                $(`#${prefix}categoriesErr`).text(err_msg);
                $(`#${prefix}categoriesErr`).slideDown(500);
            }

            if (['', 'null', null, 'undefined'].includes(data.get('trainer_id'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.trainer_id is required"); ?>';
                $(`#${prefix}trainer_idErr`).text(err_msg);
                $(`#${prefix}trainer_idErr`).slideDown(500);
            }

            if (data.get('subscription_type') == '' || !['limitted', 'unlimitted'].includes(data.get('subscription_type'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.subscription_type is required"); ?>';
                $(`#${prefix}subscription_typeErr`).text(err_msg);
                $(`#${prefix}subscription_typeErr`).slideDown(500);
            }

            if (data.get('subscription_type') == 'limitted' && (data.get('subscription_long') == '' || data.get('subscription_long') <= 0)) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.subscription_long is required"); ?>';
                $(`#${prefix}subscription_longErr`).text(err_msg);
                $(`#${prefix}subscription_longErr`).slideDown(500);
            }

            if (data.get('price') <= 0) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.price is required"); ?>';
                $(`#${prefix}priceErr`).text(err_msg);
                $(`#${prefix}priceErr`).slideDown(500);
            }

            if (data.get('trainer_ratio') <= 0) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses.trainer_ratio is required"); ?>';
                $(`#${prefix}trainer_ratioErr`).text(err_msg);
                $(`#${prefix}trainer_ratioErr`).slideDown(500);
            }

            if (prefix == '' && ['', 'undefined'].includes(data.get('image'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.image_required"); ?>';
                $(`#${prefix}imageErr`).text(err_msg); // Corrected line
                $(`#${prefix}imageErr`).slideDown(500); // Corrected line
            }

            if (['', 'undefined'].includes(data.get('image'))) {
                data.delete('image');
            }

            if (prefix == '' && Boolean(data.get('image')) && ($(`#image`).get(0).files[0].size / (10 ** 6)) > 10) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.max_file_size"); ?>';
                $(`#${prefix}imageErr`).text(err_msg); // Corrected line
                $(`#${prefix}imageErr`).slideDown(500); // Corrected line
            }

            return is_valide;
        };

        objects_dynamic_table.showDataForm = async (targetBtn) => {
        
            let target_user = $(targetBtn).data('object-id');
            let keys = [
                    'ar_title', 'en_title',
                    'ar_description', 'en_description', 'type', 
                    'subscription_type', 'subscription_long'];
            
            let response = await axios.get(`<?php echo e(url('admin/courses')); ?>/${target_user}`);

            let { data, success } = response.data;
            
            
            if (success) {
                keys.forEach(key => {
                    $(`#show-${key}`).text(Boolean(data[key]) ? data[key] : '---');
                });

                $(`#show-price`).text(Boolean(data.price) ? `${data.price} <?php echo e(ENV('APP_CURRENCY')); ?>` : '---');
                $(`#show-trainer_ratio`).text(Boolean(data.trainer_ratio) ? `${data.trainer_ratio} %` : '---');

                
                if (Boolean(data.categories)) {
                    let tmp = '';

                    data.categories.forEach(category => {
                        tmp += `
                            <span class="badge bg-primary">${lang == 'ar' ? category.ar_name : category.en_name}</span>
                        `;
                    });

                    $('#show-categories').html(tmp);
                } else {
                    $('#show-categories').html('');
                }

                $('#show-image').attr('src', Boolean(data.image) ? '<?php echo e(url("/")); ?>/' + data.image : '')
                
                $('#show-trainer').html(Boolean(data.trainer?.name) ? data.trainer.name : '---');
                
                return true;
            }

            return false;
        };
        
        objects_dynamic_table.addDataToForm = (fields_id_list, imgs_fields, data, prefix) => {
            $('#edit-categories, #edit-trainer_id').empty('disabled').trigger('change');

            fields_id_list = fields_id_list.filter(el_id => !imgs_fields.includes(el_id));
            
            fields_id_list.forEach(el_id => {
                if (!['specialties', 'trainer_files'].includes(el_id)) {
                    $(`#${prefix + el_id}`).val(data[el_id]).change();
                }
            });
            
            if(Boolean(data.trainer)) {
                let tmp = new Option(data.trainer.name, data.trainer.id, false, true);
                $('#edit-trainer_id').append(tmp);
                $('#edit-trainer_id').removeAttr('disabled').trigger('change');
            }

            if(Boolean(data.categories)) {
                data.categories.forEach(category => {
                    let tmp = new Option(`${lang == 'ar' ? category.ar_name : category.en_name }`, category.id, false, true);
                    $('#edit-categories').append(tmp);
                });

                $('#edit-categories').removeAttr('disabled').trigger('change');
            }
            
        };

        const init = (() => {
            let lang = "<?php echo e($lang); ?>";
            
            $('#categories, #edit-categories, #s-categories').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Course_Category'); ?>",
                ajax: {
                    url: '<?php echo e(url("admin/course-categories-search")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_name : item.en_name,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#trainer_id, #edit-trainer_id, #s-trainers').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Trainer'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.trainers")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : `${item.name} - ${item.phone}`,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#dataTable').on('change', '.c-top_courset-btn', function (e, current_objct = objects_dynamic_table) {
                let target_id = $(this).data('target-obj');

                axios.post(`${current_objct.routs.update_route}/${target_id}`, {
                    _token  : $('meta[name="csrf-token"]').attr('content'),
                    _method : 'PUT',
                    is_top_object: true
                }).then(res => {
                    const { success, msg } = res.data;

                    if (!success) {
                        $(this).prop('checked', !$(this).prop('checked'));
                        
                        current_objct.showAlertMsg(Boolean(msg) ? msg : 'Somthing went rong please refresh the page!!', current_objct.msg_container.danger_el);
                    } else {
                        current_objct.showAlertMsg(msg, current_objct.msg_container.success_el);
                    }
                })// axios
            });
            

        })();
        
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses/index.blade.php ENDPATH**/ ?>