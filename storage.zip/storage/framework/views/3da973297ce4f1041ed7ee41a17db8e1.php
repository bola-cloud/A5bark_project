<div style="display: none" id="createObjectCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('track_courses.Create Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#createObjectCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
        
        <div class="my-2 row">
            <label for="grade_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Grade'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="grade_id" data-target="#track_id"></select>
                <div style="padding: 5px 7px; display: none" id="grade_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="track_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Track'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" disabled="disabled" id="track_id"></select>
                <div style="padding: 5px 7px; display: none" id="track_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="ar_title" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Title'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-5" style="direction: rtl">
                <input type="text" class="form-control custome-ar-field" id="ar_title" placeholder="أسم الدورة بالعربية">
                <div style="padding: 5px 7px; display: none" id="ar_titleErr" class="err-msg mt-2 alert alert-danger custome-ar-field">
                </div>
            </div><!-- /.col-5 -->
            <div class="col-5" style="direction: rtl">
                <input type="text" class="form-control custome-en-field" id="en_title" placeholder="Course name in english">
                <div style="padding: 5px 7px; display: none" id="en_titleErr" class="err-msg mt-2 alert alert-danger custome-en-field">
                </div>
            </div><!-- /.col-5 -->
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="ar_description" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Description'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-5" style="direction: rtl">
                <textarea type="text" class="form-control custome-ar-field" id="ar_description" placeholder="الوصف بالعربية"></textarea>
                <div style="padding: 5px 7px; display: none" id="ar_descriptionErr" class="err-msg mt-2 alert alert-danger custome-ar-field">
                </div>
            </div><!-- /.col-5 -->
            <div class="col-5" style="direction: rtl">
                <textarea type="text" class="form-control custome-en-field" id="en_description" placeholder="Description in english"></textarea>
                <div style="padding: 5px 7px; display: none" id="en_descriptionErr" class="err-msg mt-2 alert alert-danger custome-en-field">
                </div>
            </div><!-- /.col-5 -->
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="number_of_sessions" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Number_Of_Sessions'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="number" min="1" class="form-control" id="number_of_sessions">
                <div style="padding: 5px 7px; display: none" id="number_of_sessionsErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="order" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Order'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="number" disabled="disabled" class="form-control" id="order">
                <div style="padding: 5px 7px; display: none" id="orderErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-3 row">
            <div class="row">
                <label for="name" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_courses.Cover'); ?> <span class="text-danger float-right">*</span></label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="cover" placeholder="<?php echo app('translator')->get('trainers.Name'); ?>" accept="image/*">
                    <div style="padding: 5px 7px; display: none" id="coverErr" class="err-msg mt-2 alert alert-danger">
                    </div>
                </div><!-- /.col-sm-10 -->
            </div><!-- /.row -->
        </div><!-- /.my-3 -->

        <button class="create-object btn btn-primary float-end"><?php echo app('translator')->get('track_courses.Create Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    $('#track_id').on('change', function () {
        let track_id = $(this).val();

        if (Boolean(track_id)) {
            // Send request latest order
            
            $('#loddingSpinner').show(500);

            axios.get(`<?php echo e(route('admin.tracks.index')); ?>/${track_id}`)
            .then((res) => {
                let { data, success } = res.data;

                console.log(data, success);

                if (success) {
                    let courses = Boolean(data.courses) ? data.courses : [];

                    let last_order = 0;

                    courses.forEach(course => {
                        if (course.order >= last_order)
                        last_order = course.order;
                    });
                    
                    $('#order').attr('max', last_order + 1).val(last_order + 1);
                    $('#order').removeAttr('disabled');
                }
            }).catch(err => {

            }).finally(() => {
                $('#loddingSpinner').hide(500);
            });
        } else {
            $('#order').attr('disabled', 'disabled').val('');
        }

    });
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/track_courses/incs/_create.blade.php ENDPATH**/ ?>