
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('track_grades.Age from'); ?></label>
            <input type="text" class="form-control" id="s-age_from">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('track_grades.Age to'); ?></label>
            <input type="text" class="form-control" id="s-age_to">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('layouts.Active'); ?></label>
            <select type="text" class="form-control" id="s-is_active">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="1"><?php echo app('translator')->get('layouts.active'); ?></option>
                <option value="0"><?php echo app('translator')->get('layouts.de-active'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/track_grades/incs/_search.blade.php ENDPATH**/ ?>