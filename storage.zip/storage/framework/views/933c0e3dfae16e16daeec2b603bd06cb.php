<?php $__env->startSection('content'); ?>
<div dir="<?php echo e(LaravelLocalization::getCurrentLocale() == 'ar' ? 'rtl' : 'ltr'); ?>" class="text-left">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0"><?php echo app('translator')->get('users.Profile'); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-end">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(url('admin')); ?>"><?php echo app('translator')->get('layouts.Dashboard'); ?></a>
                        </li>
                        
                        <li class="breadcrumb-item active">
                            <?php echo app('translator')->get('layouts.Profile'); ?>
                        </li>
                    </ol>
                </div>
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div><!-- /.content-header -->

    <div class="container-fluid">

        <div id="successAlert" style="display: none" class="alert alert-success"></div>
        
        <div id="dangerAlert"  style="display: none" class="alert alert-danger"></div>
            
        <div id="warningAlert" style="display: none" class="alert alert-warning"></div>

        <div class="d-flex justify-content-center mb-3">
            <div id="loddingSpinner" style="display: none" class="spinner-border" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>

        <div id="objectsCard" class="card card-body">
            <div class="row mb-4">
                <div class="col-6">
                    <h5><?php echo app('translator')->get('users.Account'); ?> <span class="text-primary mx-2">"<?php echo e($target_user->name); ?>"</span></h5>
                </div>
                <div class="col-6 text-end">
                    <?php if(auth()->user()->hasRole('admin') || auth()->user()->isAbleTo(['users_add']) || $target_user->id == auth()->user()->id ): ?>
                    <div class="toggle-btn btn btn-warning btn-sm" data-current-card="#objectsCard" data-target-card="#editObjectCard">
                        <i class="fas fa-edit"></i>
                    </div>
                    <?php endif; ?>
                </div>
            </div><!-- /.row -->
            
            <!-- START SEARCH BAR -->
            <div class="">
                <table class="table">
                    <tr>
                        <td><?php echo app('translator')->get('users.Email'); ?></td>
                        <td><?php echo e(isset($target_user->email) ? $target_user->email : '---'); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo app('translator')->get('users.Phone'); ?></td>
                        <td><?php echo e(isset($target_user->phone) ? $target_user->phone : '---'); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo app('translator')->get('users.Category'); ?></td>
                        <td><?php echo e(isset($target_user->category) ? $target_user->category : '---'); ?></td>
                    </tr>
                    <tr>
                        <td><?php echo app('translator')->get('users.Role'); ?></td>
                        <td>
                            <?php if(sizeof($target_user->roles)): ?>
                                <?php $__currentLoopData = $target_user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-pill badge-primary"><?php echo e($role->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                                --- 
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <td><?php echo app('translator')->get('users.Permissions'); ?></td>
                        <td>
                            <?php if(sizeof($target_user->permissions)): ?>
                                <?php $__currentLoopData = $target_user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-pill bg-primary"><?php echo e($permission->display_name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?> 
                                --- 
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div><!-- /.card --> 

        <?php echo $__env->make('admin.profiles.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    $('.toggle-btn').click(function () {
        let target_card = $(this).data('target-card');
        let current_card = $(this).data('current-card');

        $(target_card).slideDown(500);
        $(current_card).slideUp(500);
        $('#dangerAlert').html('').slideUp(500);
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/profiles/index.blade.php ENDPATH**/ ?>