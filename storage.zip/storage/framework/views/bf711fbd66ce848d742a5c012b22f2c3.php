
<div style="display: none" id="showObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('users.Show User'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#showObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <div>
        <table class="table">
            <tr>
                <td><?php echo app('translator')->get('users.Name'); ?></td>
                <td id="show-name"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('users.Email'); ?></td>
                <td id="show-email"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('users.Phone'); ?></td>
                <td id="show-phone"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('users.Category'); ?></td>
                <td id="show-category"></td>
            </tr>
            
            <tr>
                <td><?php echo app('translator')->get('users.Role'); ?></td>
                <td id="show-role"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('users.Permissions'); ?></td>
                <td id="show-permissions"></td>
            </tr>
        
        </table>
    </div>
</div><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/users/incs/_show.blade.php ENDPATH**/ ?>