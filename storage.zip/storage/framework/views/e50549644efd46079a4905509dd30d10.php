<div style="display: none" id="createObjectCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('promo_codes.Create Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#createObjectCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
        
        <div class="my-2 row">
            <label for="trainer_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Trainer'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="trainer_id"></select>
                <div style="padding: 5px 7px; display: none" id="trainer_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="title" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Title'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input class="form-control" id="title" placeholder="<?php echo app('translator')->get('promo_codes.Title'); ?>">
                <div style="padding: 5px 7px; display: none" id="titleErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="number_of_promos" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Number_Of_Promos'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="number" class="form-control" min="1" max="5000" id="number_of_promos" />
                <div style="padding: 5px 7px; display: none" id="number_of_promosErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="courses" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Courses'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select multiple="multiple" class="form-control" id="courses"></select>
                <div style="padding: 5px 7px; display: none" id="coursesErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="expiry_date" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Expiry_Date'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="date" class="form-control" id="expiry_date" />
                <div style="padding: 5px 7px; display: none" id="expiry_dateErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="type" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Type'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="type">
                    <option value=""><?php echo app('translator')->get('promo_codes.select_type'); ?></option>
                    <option value="free"><?php echo app('translator')->get('promo_codes.free'); ?></option>
                    <option value="discount"><?php echo app('translator')->get('promo_codes.discount'); ?></option>
                </select>
                <div style="padding: 5px 7px; display: none" id="typeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row promo-type is-discount" style="display: none">
            <label for="discount_ratio" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Discount_Ratio'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" min="1" max="100" id="discount_ratio" />
                <div style="padding: 5px 7px; display: none" id="discount_ratioErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 pt-1">
                <span class="badge text-bg-primary fs-6">%</span>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row promo-type is-discount" style="display: none">
            <label for="discount_limit" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Discount_Limit'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" min="1" max="100" id="discount_limit" />
                <div style="padding: 5px 7px; display: none" id="discount_limitErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 pt-1">
                <span class="badge text-bg-primary fs-6"><?php echo e(ENV('APP_CURRENCY')); ?></span>
            </div>
        </div><!-- /.my-2 -->
        
        <button class="create-object btn btn-primary float-end"><?php echo app('translator')->get('promo_codes.Create Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    $('#type').change(function () {
        let val = $(this).val();

        if (val == 'discount') {
            $('.is-discount').slideDown(500);
        } else {
            $('.promo-type').slideUp(500);
        }

    });
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_folders/incs/_create.blade.php ENDPATH**/ ?>