<div style="display: none" id="createObjectCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('courses.Create Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#createObjectCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
        
        <div class="my-2 row">
            <label for="ar_title" class="col-sm-2 col-form-label"><?php echo app('translator')->get('course_category.Name'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-5" style="direction: rtl">
                <input type="text" class="form-control custome-ar-field" id="ar_title" placeholder="أسم التصنيف بالعربية">
                <div style="padding: 5px 7px; display: none" id="ar_titleErr" class="err-msg mt-2 alert alert-danger custome-ar-field">
                </div>
            </div><!-- /.col-5 -->
            <div class="col-5" style="direction: rtl">
                <input type="text" class="form-control custome-en-field" id="en_title" placeholder="Category name in english">
                <div style="padding: 5px 7px; display: none" id="en_titleErr" class="err-msg mt-2 alert alert-danger custome-en-field">
                </div>
            </div><!-- /.col-5 -->
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="ar_description" class="col-sm-2 col-form-label"><?php echo app('translator')->get('course_category.Description'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-5" style="direction: rtl">
                <textarea type="text" class="form-control custome-ar-field" id="ar_description" placeholder="الوصف بالعربية"></textarea>
                <div style="padding: 5px 7px; display: none" id="ar_descriptionErr" class="err-msg mt-2 alert alert-danger custome-ar-field">
                </div>
            </div><!-- /.col-5 -->
            <div class="col-5" style="direction: rtl">
                <textarea type="text" class="form-control custome-en-field" id="en_description" placeholder="Description in english"></textarea>
                <div style="padding: 5px 7px; display: none" id="en_descriptionErr" class="err-msg mt-2 alert alert-danger custome-en-field">
                </div>
            </div><!-- /.col-5 -->
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="subscription_type" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Subscription_Type'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="subscription_type">
                    <option value=""><?php echo app('translator')->get('courses.Select Subscription Type'); ?></option>
                    <option value="limitted"><?php echo app('translator')->get('courses.Limitted'); ?></option>
                    <option value="unlimitted"><?php echo app('translator')->get('courses.Unlimitted'); ?></option>
                </select>
                <div style="padding: 5px 7px; display: none" id="subscription_typeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row subscription_long-component" style="display: none">
            <label for="subscription_long" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Subscription_Long'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" min="1" class="form-control" id="subscription_long" />
                <div style="padding: 5px 7px; display: none" id="subscription_longErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1">
                <span class="badge bg-primary mt-2"><?php echo app('translator')->get('courses.Month'); ?></span>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="categories" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Categories'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="categories" multiple="multiple"></select>
                <div style="padding: 5px 7px; display: none" id="categoriesErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="trainer_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Trainer'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="trainer_id"></select>
                <div style="padding: 5px 7px; display: none" id="trainer_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="price" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Price'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" id="price" multiple="multiple">
                <div style="padding: 5px 7px; display: none" id="priceErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 text-center">
                <span class="badge bg-primary mt-2"><?php echo app('translator')->get('courses.Pound'); ?></span>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="trainer_ratio" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses.Trainer Ratio'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" id="trainer_ratio" multiple="multiple">
                <div style="padding: 5px 7px; display: none" id="trainer_ratioErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 text-center">
                <span class="badge bg-primary mt-2">%</span>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-3 row">
            <div class="row">
                <label for="image" class="col-sm-2 col-form-label"><?php echo app('translator')->get('track_grades.Image'); ?> <span class="text-danger float-right">*</span></label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="image" placeholder="<?php echo app('translator')->get('trainers.Name'); ?>" accept="image/*">
                    <div style="padding: 5px 7px; display: none" id="imageErr" class="err-msg mt-2 alert alert-danger">
                    </div>
                </div><!-- /.col-sm-10 -->
            </div><!-- /.row -->
        </div><!-- /.my-3 -->

        <button class="create-object btn btn-primary float-end"><?php echo app('translator')->get('courses.Create Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    
    $('#subscription_type').on('change', function () {
        let val = $(this).val();

        val == 'limitted' 
            ? $('.subscription_long-component').slideDown(500) 
            : $('.subscription_long-component').slideUp(500);
    });

});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses/incs/_create.blade.php ENDPATH**/ ?>