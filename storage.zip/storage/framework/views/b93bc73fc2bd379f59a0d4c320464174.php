<div style="display: none" id="createObjectCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('courses_subscriptions.Create Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#createObjectCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
            
        <div class="my-3 row">
            <label for="subscription_type" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Subscription_Type'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="subscription_type">
                    <option value=""><?php echo app('translator')->get('courses_subscriptions.select_content_type'); ?></option>
                    <option value="course"><?php echo app('translator')->get('courses_subscriptions.courses'); ?></option>
                    <option value="grade"><?php echo app('translator')->get('courses_subscriptions.grades'); ?></option>
                </select>
                <div style="padding: 5px 7px; display: none" id="subscription_typeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-3 -->

        <div class="my-3">
            <div id="course-fields" style="display: none">
                <div class="my-3 row">
                    <label for="course_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Course'); ?> <span class="text-danger float-right">*</span></label>
                    <div class="col-sm-10">
                        <select class="form-control" id="course_id"></select>
                        <div style="padding: 5px 7px; display: none" id="course_idErr" class="err-msg mt-2 alert alert-danger">
                        </div>
                    </div>
                </div><!-- /.my-3 -->
                
                <div class="my-3 row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-10">
                        <table class="table">
                            <tr>
                                <td><?php echo app('translator')->get('courses.Name'); ?></td>
                                <td class="text-right" id="creat-ar_title"></td>
                                <td class="text-left" id="creat-en_title"></td>
                            </tr>

                            <tr>
                                <td><?php echo app('translator')->get('courses.Categories'); ?></td>
                                <td colspan="2" id="creat-categories"></td>
                            </tr>

                            <tr>
                                <td><?php echo app('translator')->get('courses.Trainer'); ?></td>
                                <td colspan="2" id="creat-trainer"></td>
                            </tr>

                            <tr>
                                <td><?php echo app('translator')->get('courses.Price'); ?></td>
                                <td colspan="2" id="creat-price"></td>
                            </tr>
                        </table>
                    </div><!-- /.col-sm-10 -->
                </div><!-- /.my-3 -->
            </div><!-- /.course-fields -->

            <div id="grades-fields" style="display: none">
                <div class="my-3 row">
                    <label for="grade_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Grade'); ?> <span class="text-danger float-right">*</span></label>
                    <div class="col-sm-10">
                        <select class="form-control" id="grade_id"></select>
                        <div style="padding: 5px 7px; display: none" id="grade_idErr" class="err-msg mt-2 alert alert-danger">
                        </div>
                    </div><!-- /.col-sm-10 -->
                </div><!-- /.my-3 -->
                
                <div class="my-3 row" style="height: 200px; overflow-y: scroll">
                    <div class="col-sm-2">
                        <input type="hidden" id="group_id">
                    </div>
                    <div class="col-sm-10">
                        <div style="padding: 5px 7px; display: none" id="group_idErr" class="err-msg my-2 alert alert-danger">
                        </div>
                        <table class="table text-center">
                            <thead>
                                <tr>
                                    <td>Group Name</td>
                                    <td>Start Date</td>
                                    <td>Days</td>
                                    <td>Time</td>
                                    <td>Number Of Students</td>
                                </tr>
                            </thead>
                            <tbody id="gradesGroupsBody"></tbody>
                        </table>
                    </div><!-- /.col-sm-10 -->
                </div><!-- /.my-3 -->

                <div class="my-3 row">
                    <label for="plan_type" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Payment_Type'); ?> <span class="text-danger float-right">*</span></label>
                    <div class="col-sm-8">
                        <input type="hidden" id="plan_id">
                        <select class="form-control" id="plan_type">
                            <option value="">-- select plan --</option>
                            <option value="1"><?php echo app('translator')->get('track_grades.Plan_1'); ?></option>
                            <option value="2"><?php echo app('translator')->get('track_grades.Plan_2'); ?></option>
                            <option value="3"><?php echo app('translator')->get('track_grades.Plan_3'); ?></option>
                        </select>
                        <div style="padding: 5px 7px; display: none" id="plan_idErr" class="err-msg mt-2 alert alert-danger">
                        </div>
                    </div><!-- /.col-sm-2 -->

                    <div class="col-sm-2 fn-5">
                        <label id="plan_type_price" class="badge bg-primary">---</label>
                    </div><!-- /.col-sm-2 -->
                </div><!-- /.my-3 -->

            </div><!-- /.course-fields -->
        </div><!-- /.my-3 -->

        <div class="my-3">
            <div class="my-3 row">
                <label for="student_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Student'); ?> <span class="text-danger float-right">*</span></label>
                <div class="col-sm-10">
                    <select class="form-control" id="student_id"></select>
                    <div style="padding: 5px 7px; display: none" id="student_idErr" class="err-msg mt-2 alert alert-danger">
                    </div>
                </div>
            </div><!-- /.my-3 -->
            
            <div class="my-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <table class="table">
                        <tr>
                            <td><?php echo app('translator')->get('students.Name'); ?></td>
                            <td class="text-right" id="creat-name"></td>
                        </tr>

                        <tr>
                            <td><?php echo app('translator')->get('students.Email'); ?></td>
                            <td id="creat-email"></td>
                        </tr>
                        
                        <tr>
                            <td><?php echo app('translator')->get('students.Phone'); ?></td>
                            <td id="creat-phone"></td>
                        </tr>

                        <tr>
                            <td><?php echo app('translator')->get('wallets.Valied Balance'); ?></td>
                            <td id="creat-valied_balance"></td>
                        </tr>
                    </table>
                </div><!-- /.col-sm-10 -->
            </div><!-- /.my-3 -->
        </div><!-- /.my-3 -->
        
        <div class="my-3 row is-free-options paied" style="!display: none">
            <label for="payment_method" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Payment_Method'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="payment_method">
                    <option value=""><?php echo app('translator')->get('courses_subscriptions.select_payment_method'); ?></option>
                    <option value="promo-code"><?php echo app('translator')->get('courses_subscriptions.promo_code'); ?></option>
                    <option value="wallet"><?php echo app('translator')->get('courses_subscriptions.wallet'); ?></option>
                    <option value="free"><?php echo app('translator')->get('courses_subscriptions.free'); ?></option>
                </select>
                <div style="padding: 5px 7px; display: none" id="payment_methodErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-3 -->

        <div class="my-3 row payment-method-options promo-code" style="display: none">
            <label for="promo_code" class="col-sm-2 col-form-label"><?php echo app('translator')->get('courses_subscriptions.Promo_Code'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input class="form-control" id="promo_code" disabled="disabled">
                <div style="padding: 5px 7px; display: none" id="promo_codeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1" id="promo_code_loader">
                <div class="spinner-border" role="status" style="display: none">
                    <span class="visually-hidden">Loading...</span>
                </div>

                <span class="text text-success fs-5" style="display: none">
                    <i class="fas fa-check-circle"></i>
                </span>
                
                <span class="text text-danger fs-5" style="display: none">
                    <i class="fas fa-times-circle"></i>
                </span>
            </div>
        </div><!-- /.my-3 -->
        
        <button class="create-object btn btn-primary float-end mt-2"><?php echo app('translator')->get('courses_subscriptions.Create Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    
    const Store = (() => {
        let meta = {
            course        : null,
            student       : null,
            grade         : null,
            groups        : [],
            group_id      : null,
            pricing_plans : [],
        };

        const getters = {
            getGroups : () => {
                return [...meta.groups];
            },

            getPricePlan : (plan_type) => {
                console.log('plan_type : ', plan_type, meta.pricing_plans)
                return meta.pricing_plans.find(plan => plan.plan_type == plan_type);
            }
        };

        const setters = {
            fetchCourse  : async (course_id) => {
                $('#loddingSpinner').show();

                let res = await axios.get(`<?php echo e(route('admin.courses.index')); ?>/${course_id}`)

                $('#loddingSpinner').hide(500);

                let { data, success } = res.data;

                meta.course = {...data};

                return {...data}
            },

            fetchStudent : async (student_id) => {
                $('#loddingSpinner').show();

                let res = await axios.get(`<?php echo e(route('admin.students.index')); ?>/${student_id}`);

                $('#loddingSpinner').hide(500);

                let { data, success } = res.data;

                meta.student = {...data};

                return {...data};
            },

            fetchPromo   : async (course_id, validate_promo) => {
                const res = await axios.get("<?php echo e(route('admin.promoCodes.index')); ?>", {
                    params : {
                        course_id,
                        promo_type : 'free',
                        validate_promo,
                    }
                });

                const { data, success } = res.data;

                return success;
            },

            fetchGrade   : async (grade_id) => {
                $('#loddingSpinner').show(500);

                const res = await axios.get(`<?php echo e(route('admin.trackGrades.index')); ?>/${grade_id}`);
                $('#loddingSpinner').hide(500);

                let { data, success } = res.data;

                console.log(data, success); 

                if (success) {
                    meta.grade         = {...data};
                    
                    meta.groups        = [...data.groups]
                    
                    meta.pricing_plans = [...data.pricing_plans];

                    // helpers.setPricingPlans(data);
                }

                return data.groups;
            },

            selectGroup : (group_id) => {
                meta.group_id = group_id;
            }
        }; 

        return {
            getters,
            setters,
        }
    })();

    const View = (() => {
        let group_id_field       = '#group_id';
        let grades_groups_body   = '#gradesGroupsBody';
        let plan_type_field      = '#plan_type';
        let plan_type_price_lab  = '#plan_type_price';
        let plan_id_filed        = '#plan_id';

        const renderCourse = (data) => {
            let course_keys = ['ar_title', 'en_title','price', 'trainer', 'categories'];
            
            if (Boolean(data)) {
                course_keys.forEach(key => {
                    $(`#creat-${key}`).text(Boolean(data[key]) ? data[key] : '---');
                });

                $(`#creat-price`).text(Boolean(data.price) ? `${data.price} <?php echo e(ENV('APP_CURRENCY')); ?>` : '---');
                $('#creat-trainer').text(Boolean(data.trainer?.name) ? data.trainer.name : '---');

                let tmp = '';

                data.categories.forEach(category => {
                    tmp += `
                        <span class="badge bg-primary">${lang == 'ar' ? category.ar_name : category.en_name}</span>
                    `;
                });

                $('#creat-categories').html(tmp);
            } else {
                course_keys.forEach(key => {
                    $(`#creat-${key}`).text('---');
                });
            }
        
        }

        const renderStudent = (data) => {
            let course_keys = ['name', 'email', 'phone', 'valied_balance'];
            
            if (Boolean(data)) {
                course_keys.forEach(key => {
                    $(`#creat-${key}`).text(Boolean(data[key]) ? data[key] : '---');
                });

                $(`#creat-valied_balance`).text(Boolean(data.wallet.valide_balance) ? `${data.wallet.valide_balance} <?php echo e(ENV('APP_CURRENCY')); ?>` : '---');

            } else {
                course_keys.forEach(key => {
                    $(`#creat-${key}`).text('---');
                });
            }
        }

        // Show / Hide promo field. 
        const togglePromoField = (clear = true) => {
            if (clear) {
                $('#promo_code').removeAttr('disabled').css('border', '').val('').trigger('change');
                $('#promo_codeErr').slideUp(500).text('');
            } else {
                $('#promo_code_loader .text-success').hide(500);
                $('#promo_code').attr('disabled', 'disabled').css('border', '1px solid red').val('');
                $('#promo_codeErr').text(`<?php echo app('translator')->get('courses_subscriptions.select_course_before_promo_code'); ?>`).slideDown(500);
            }
        }

        // Check if promo-code is correct animation.
        const searchPromoCodeAnimation = (state = null) => {
            switch (state) {
                case 'found':
                    $('#promo_code').css('border', '1px solid green');
                    $('.create-object').removeAttr('disabled');
                    $('#promo_code_loader .text-success').show(500);
                    $('#promo_code_loader .spinner-border').hide(100);
                    break;
                case 'not-found':
                    $('#promo_code').css('border', '1px solid red');
                    $('.create-object').attr('disabled', 'disabled');
                    $('#promo_code_loader .text-danger').show(500);
                    $('#promo_code_loader .spinner-border').hide(100);
                    break;
                default :    
                    $('#promo_code').css('border', '');
                    $('.create-object').attr('disabled', 'disabled');
                    $('#promo_code_loader .text').hide();
                    $('#promo_code_loader .spinner-border').fadeIn(500);
            }
        };

        // ---  ---

        // Show / Hide conten type Courses, or Grades
        const toggleContentType = (type) => {
            if (type == 'course') {
                $('#course-fields').slideDown(500);
                $('#grades-fields').slideUp(500);
            } else if (type == 'grade') {
                $('#course-fields').slideUp(500);
                $('#grades-fields').slideDown(500);
            } else {
                $('#course-fields').slideUp(500);
                $('#grades-fields').slideUp(500);
            }
        }

        const renderGroupsList = (groups, group_id = null) => {
            let groupls_list = '';

            groups.forEach(group => {
                groupls_list += `
                    <tr class="group-el" data-target="${group.id}" style="cursor: pointer;">
                        <td>${group.title}</td>
                        <td>${group.start_date}</td>
                        <td>${group.days}</td>
                        <td>${group.time}</td>
                        <td>${ '0' }</td>
                        <td class="fs-5">
                            ${
                                group.id == group_id 
                                    ? '<i class="text-success fas fa-check-circle"></i>'
                                    : '<i class="fas fa-exclamation-circle"></i>'
                            }
                        </td>
                    </tr>
                `;
            });

            $(plan_type_field).val('');
            $(group_id_field).val(group_id);
            $(grades_groups_body).html(groupls_list);
        }

        const renderPlanPrice = (plan = null) => {
            if (Boolean(plan)) {
                $(plan_id_filed).val(plan.id);
                $(plan_type_price_lab).text(`${plan.price} <?php echo e(ENV('APP_CURRENCY')); ?>`);
            } else {
                $(plan_id_filed).val('');
                $(plan_type_field).val();
                $(plan_type_price_lab).text('---');
            }
        }

        return  {
            renderCourse,
            renderStudent,
            togglePromoField,
            searchPromoCodeAnimation,
            
            toggleContentType,
            renderGroupsList,
            renderPlanPrice,

            grades_groups_body,
            plan_type_field
        }
    })();

    (() => {
        const { setters, getters } = Store;

        // When a user select a course, show course data & clear promo-code field.  
        $('#course_id').on('change', async function () {
            let course_id   = $(this).val();
            let course_keys = ['ar_title', 'en_title', 'ar_description', 'en_description', ];

            if (Boolean(course_id)) {

                let data = await setters.fetchCourse(course_id);

                Boolean(data) && View.renderCourse(data);

                View.togglePromoField()
                
            } else {
                
                View.renderCourse(null)
                View.togglePromoField(false)
            }

        });

        // When a user select a student, show student data.
        $('#student_id').on('change', async function () {
            let student_id   = $(this).val();
            
            console.log('Test student : ', student_id);

            if (Boolean(student_id)) {

                let data = await setters.fetchStudent(student_id);

                Boolean(data) && View.renderStudent(data);

            } else {
                View.renderStudent(null)
            }
        });

        // Handle payment method sub fieldes  
        $('#payment_method').on('change', function () {
            let payment_method = $(this).val();

            $('.payment-method-options').slideUp(500);
            
            switch (payment_method) {
                case 'promo-code':
                    $('.promo-code').slideDown(500);
                    $('.create-object').attr('disabled', 'disabled');
                    break;
                default :
                    $('.promo-code').slideUp(500);
                    $('.create-object').removeAttr('disabled');
            }
        });

        // Validate promo code
        $('#promo_code').on('change, keyup', function () {

            Boolean(window.promo_code_req) && clearInterval(window.promo_code_req);

            window.promo_code_req = setTimeout(async () => {
                /**
                 *  1- Get input from the field
                 *  2- Send request to make sure that the promo exists and gives free
                 *  3- Show the result of the promo check request
                 */
                
                let input     = $(this).val();
                let course_id = $('#course_id').val();

                // loading animation
                View.searchPromoCodeAnimation()

                // send request
                let success = await setters.fetchPromo(course_id, input);
                
                View.searchPromoCodeAnimation(success ? 'found' : 'not-found');
            
            }, 600);
        });


        // --- ---

        // Toggle subscription content type
        $('#subscription_type').on('change', function () {
            let type = $(this).val();

            View.toggleContentType(type);
        });

        $('#grade_id').on('change', async function () {
            let grade_id = $(this).val();

            if (Boolean(grade_id)) {
                let groups = await setters.fetchGrade(grade_id);
                
                setters.selectGroup(null);
                
                View.renderGroupsList(groups);
            } else {
                View.renderGroupsList([]);
            }
                
            View.renderPlanPrice();
        });

        $(View.grades_groups_body).on('click', '.group-el', function () {
            let group_id = $(this).data('target');

            if (Boolean(group_id)) {
                setters.selectGroup(group_id);
                
                View.renderGroupsList(getters.getGroups(), group_id);
            }
        });

        $(View.plan_type_field).on('change', function () {
            let plan_type = $(this).val();

            console.log('plan_type : ', plan_type)

            if (Boolean(plan_type)) {
                let plan = getters.getPricePlan(plan_type);
                View.renderPlanPrice(plan);
            } else {
                View.renderPlanPrice();
            }

        })

    })();

});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses_subscriptions/incs/_create.blade.php ENDPATH**/ ?>