<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3 sidebar-sticky">
        <?php 
            $user_category = auth()->user()->category;  
        ?>

        <?php if( $user_category == 'admin' 
            || auth()->user()->isAbleTo('dashboard_*') 
            || auth()->user()->isAbleTo('users_*')
            || auth()->user()->isAbleTo('roles_*') 
            || auth()->user()->isAbleTo('students_*') 
        ): ?>
        <ul class="nav flex-column">
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'admin') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.dashboard.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Dashboard'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('users_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/users') ? 'active' : ''); ?>" href="<?php echo e(route('admin.users.index')); ?>">
                    <i class="fas fa-user-cog"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Users'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('roles_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/roles') ? 'active' : ''); ?>" href="<?php echo e(route('admin.roles.index')); ?>">
                    <i class="fas fa-id-card-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Roles'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('students_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/students') ? 'active' : ''); ?>" href="<?php echo e(route('admin.students.index')); ?>">
                    <i class="fas fa-child"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Students'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('parents_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/parents') ? 'active' : ''); ?>" href="<?php echo e(route('admin.parents.index')); ?>">
                    <i class="fas fa-users"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Parents'); ?></span>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('trainers_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/trainers') ? 'active' : ''); ?>" href="<?php echo e(route('admin.trainers.index')); ?>">
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Trainers'); ?></span>
                </a>
            </li>
            <?php endif; ?>

        </ul>
        <?php endif; ?>


        <?php if( $user_category == 'admin' 
            || auth()->user()->isAbleTo('courses_*') 
            || auth()->user()->isAbleTo('courseSubscription_*') 
            || auth()->user()->isAbleTo('courseTransactions_*') 
        ): ?>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span><?php echo app('translator')->get('layouts.Courses Platform'); ?></span>
        </h6>
        
        <ul class="nav flex-column mb-2">
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('courses_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/courses') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courses.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Courses'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('tracks*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/tracks') ? 'active' : ''); ?>" href="<?php echo e(route('admin.tracks.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-chalkboard-teacher"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Tracks'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('trackCourses*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/track-courses') ? 'active' : ''); ?>" href="<?php echo e(route('admin.trackCourses.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-clipboard-list"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Track Courses'); ?></span>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('gradeGroups*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/grade-groups') ? 'active' : ''); ?>" href="<?php echo e(route('admin.gradeGroups.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-users-cog"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Grades Groups'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('courseSubscription_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/courses-subscriptions') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courseSubscription.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-shopping-cart"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Courses Subscriptions'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('courseTransactions_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/courses-transactions') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courseTransactions.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-cash-register"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Courses Transactions'); ?></span>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('promoFolders_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/promo-folders') ? 'active' : ''); ?>" href="<?php echo e(route('admin.promoFolders.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-folder"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Promo Folders'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('promoCodes_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/promo-codes') ? 'active' : ''); ?>" href="<?php echo e(route('admin.promoCodes.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <i class="fas fa-tag"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Promo Codes'); ?></span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>

        <?php if( $user_category == 'admin' 
            || auth()->user()->isAbleTo('wallets_*') 
            || auth()->user()->isAbleTo('walletsCharges_*')
            || auth()->user()->isAbleTo('transactions_*') 
        ): ?>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span><?php echo app('translator')->get('layouts.Financials'); ?></span>
        </h6>
        
        <ul class="nav flex-column mb-2">
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('wallets_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), '/wallets') ? 'active' : ''); ?>" href="<?php echo e(route('admin.wallets.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <?php echo app('translator')->get('layouts.Wallets'); ?>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('walletsCharges_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/wallets-charges') ? 'active' : ''); ?>" href="<?php echo e(route('admin.walletsCharges.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <?php echo app('translator')->get('layouts.Wallets Charges'); ?>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        <?php endif; ?>

        <?php if( $user_category == 'admin' 
            || auth()->user()->isAbleTo('districts_*') 
        ): ?>
        <h6 class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span><?php echo app('translator')->get('layouts.Settings'); ?></span>
        </h6>

        <ul class="nav flex-column mb-2">
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('districts_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/districts') ? 'active' : ''); ?>" href="<?php echo e(route('admin.districts.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <?php echo app('translator')->get('layouts.Districts'); ?>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('districts_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/course-categories') ? 'active' : ''); ?>" href="<?php echo e(route('admin.courseCategories.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <?php echo app('translator')->get('layouts.Course Categories'); ?>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('districts_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_contains(Request::path(), '/track-grades') ? 'active' : ''); ?>" href="<?php echo e(route('admin.trackGrades.index')); ?>">
                <span data-feather="file-text" class="align-text-bottom"></span>
                    <?php echo app('translator')->get('layouts.Track Grades'); ?>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('settings_*') ): ?>
            
            <?php endif; ?>
            
            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text" class="align-text-bottom"></span>
                </a>
            </li>
        </ul>
        <?php endif; ?>
        
    </div>
</nav><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/layouts/admin/incs/_navbar.blade.php ENDPATH**/ ?>