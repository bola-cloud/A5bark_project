
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('roles.Name'); ?></label>
            <input type="text" class="form-control" id="s-name">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    

</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/roles/incs/_search.blade.php ENDPATH**/ ?>