<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3 sidebar-sticky">
        <?php 
            $user_category = auth()->user()->category;  
        ?>

        <?php if( $user_category == 'admin' 
            || auth()->user()->isAbleTo('dashboard_*') 
            || auth()->user()->isAbleTo('users_*')
            || auth()->user()->isAbleTo('roles_*') 
            || auth()->user()->isAbleTo('students_*') 
        ): ?>
        <ul class="nav flex-column">
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'admin') ? 'active' : ''); ?>" aria-current="page" href="<?php echo e(route('admin.dashboard.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.Dashboard'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'news_category') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.news_category.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.News_category'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'news') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.news.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.News'); ?></span>
                </a>
            </li>
            <?php endif; ?>
           
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'festival') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.festival.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.festival'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'playlist') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.playlist.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.playlist'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'episodes') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.episodes.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.episodes'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'event') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.event.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.event'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'motion') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.motion.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.motion'); ?></span>
                </a>
            </li>
            <?php endif; ?>
            
            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'adverticement') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.adverticement.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.adverticement'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'branch') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.branch.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.branches'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <?php if( $user_category == 'admin' || auth()->user()->isAbleTo('dashboard_*') ): ?>
            <li class="nav-item">
                <a class="nav-link <?php echo e(str_ends_with(Request::path(), 'places') ? 'active' : ''); ?>" aria-current="page2" href="<?php echo e(route('admin.places.index')); ?>">
                    <i class="fas fa-tachometer-alt"></i>
                    <span class="mx-1"><?php echo app('translator')->get('layouts.places'); ?></span>
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link" href="#">
                    <span data-feather="file-text" class="align-text-bottom"></span>
                </a>
            </li>
        </ul>
        <?php endif; ?>
        
    </div>
</nav><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/layouts/admin/incs/_navbar.blade.php ENDPATH**/ ?>