

<?php $__env->startSection('content'); ?>

<div class="container-fluid ">
    <div class="container">
        <div class="row d-flex flex-column mt-5">
            <h1 class="d-flex justify-content-center blue-color mt-5"> الاخبار <?php echo e($news->newsCategory->ar_name); ?></h1>
            <h4 class="d-flex justify-content-start mt-4">  <?php echo e($news->ar_head); ?>  </h4>
            <h4 class="d-flex justify-content-start text-danger"> <?php
                    setlocale(LC_TIME, 'ar_AE.UTF-8'); // Set the locale to Arabic
                    \Carbon\Carbon::setLocale('ar');
                    $createdAt = \Carbon\Carbon::parse($news->created_at);
                ?>
                <span><?php echo e($createdAt->translatedFormat('l، d F Y - H:i')); ?></span>
            </h4>
        </div>
    </div>
    <div class="row p-5">
        <div class="col-md-12">
            <img src="<?php echo e(asset('media/'.$news->image)); ?>" alt="" class="w-100">
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 pr-5 pl-5 mb-5">
                <h4 class="d-flex justify-content-start mt-4">
                    <?php echo e($news->ar_title); ?>


                </h4>
                <h4 class="d-flex justify-content-start mt-4 text-justify"> <?php echo e($news->ar_content); ?> </h4>
            </div>
        </div>
    </div>

</div> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/front/news-details.blade.php ENDPATH**/ ?>