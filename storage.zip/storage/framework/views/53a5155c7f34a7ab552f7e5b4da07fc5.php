<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Grades Groups'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('grade_groups.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('courses_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.grade_groups.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('grade_groups.Title'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Grade'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Start_Date'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Time'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Days'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Number_Of_Sessions'); ?></th>
                        <th><?php echo app('translator')->get('grade_groups.Subscribers'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    <?php if($permissions == 'admin' || in_array('tracks_add', $permissions)): ?>
        <?php echo $__env->make('admin.grade_groups.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('tracks_show', $permissions)): ?>
        <?php echo $__env->make('admin.grade_groups.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('tracks_edit', $permissions)): ?>
        <?php echo $__env->make('admin.grade_groups.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('document').ready(function () {
        let lang = "<?php echo e($lang); ?>";

        const objects_dynamic_table = new DynamicTable(
            {
                index_route   : "<?php echo e(route('admin.gradeGroups.index')); ?>",
                store_route   : "<?php echo e(route('admin.gradeGroups.store')); ?>",
                show_route    : "<?php echo e(route('admin.gradeGroups.index')); ?>",
                update_route  : "<?php echo e(route('admin.gradeGroups.index')); ?>",
                destroy_route : "<?php echo e(route('admin.gradeGroups.index')); ?>",
            },
            '#dataTable',
            {
                success_el : '#successAlert',
                danger_el  : '#dangerAlert',
                warning_el : '#warningAlert'
            },
            {
                table_id        : '#dataTable',
                toggle_btn      : '.toggle-btn',
                create_obj_btn  : '.create-object',
                update_obj_btn  : '.update-object',
                fields_list     : [
                    'id',
                    'title', 'start_date', 'days', 'time', 
                    'number_of_sessions', 'grade_id', 'meta'
                ],
                imgs_fields     : []
            },
            [
                { data: 'id',           name: 'id' },
                { data: 'title',        name: 'title' },
                { data: 'grade',        name: 'grade' },
                { data: 'start_date',   name: 'start_date' },
                { data: 'time',         name: 'time' },
                { data: 'days',         name: 'days' },
                { data: 'number_of_sessions',         name: 'number_of_sessions' },
                { data: 'subscribers',  name: 'subscribers' },
                { data: 'activation',   name: 'activation' },
                { data: 'actions',      name: 'actions' },
            ],
            function (d) {
                if ($('#s-name').length)
                d.name = $('#s-name').val(); 

                if ($('#s-trainers').length)
                d.trainers = $('#s-trainers').val();  
                
                if ($('#s-categories').length)
                d.categories = $('#s-categories').val();  

                if ($('#s-grades').length)
                d.grades = $('#s-grades').val();  
                
                if ($('#s-is_active').length)
                d.is_active = $('#s-is_active').val(); 
            }
        );

        objects_dynamic_table.validateData = (data, prefix = '') => {
            // inite validation flag
            let is_valide = true;

            // clear old validation session
            $('.err-msg').slideUp(500);

            if (data.get('title') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.title is required"); ?>';
                $(`#${prefix}titleErr`).text(err_msg);
                $(`#${prefix}titleErr`).slideDown(500);
            }

            if (data.get('start_date') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.start_date is required"); ?>';
                $(`#${prefix}start_dateErr`).text(err_msg);
                $(`#${prefix}start_dateErr`).slideDown(500);
            }

            if (data.get('days') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.days is required"); ?>';
                $(`#${prefix}daysErr`).text(err_msg);
                $(`#${prefix}daysErr`).slideDown(500);
            }

            if (data.get('time') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.time is required"); ?>';
                $(`#${prefix}timeErr`).text(err_msg);
                $(`#${prefix}timeErr`).slideDown(500);
            }

            if (['', 'null', null, 'undefined'].includes(data.get('grade_id'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.grade_id is required"); ?>';
                $(`#${prefix}grade_idErr`).text(err_msg);
                $(`#${prefix}grade_idErr`).slideDown(500);
            }

            if (['', 'null', 0, 'undefined', '0'].includes(data.get('number_of_sessions'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("grade_groups.number_of_sessions_is_required"); ?>';
                $(`#${prefix}number_of_sessionsErr`).text(err_msg);
                $(`#${prefix}number_of_sessionsErr`).slideDown(500);
            }

            return is_valide;
        };

        objects_dynamic_table.showDataForm = async (targetBtn) => {
            $('#nav-home-tab').trigger('click');

            let target_id = $(targetBtn).data('object-id');
            
            let keys      = ['title', 'start_date', 'time', 'days', 'number_of_sessions'];
            
            let response = await axios.get(`<?php echo e(route('admin.gradeGroups.index')); ?>/${target_id}`);

            let { data, success } = response.data;
            
            if (success) {
                keys.forEach(key => {
                    $(`#show-${key}`).text(Boolean(data[key]) ? data[key] : '---');
                });

                if (Boolean(data.grade)) {
                    $(`#show-grade`).text(lang ? data.grade.ar_title : data.grade.en_title)
                } else {
                    $(`#show-grade`).text('');
                }
                
                if (Boolean(data.schedule)) {
                    let schedule_el = '';

                    data.schedule.forEach(schedule => {
                        schedule_el += `
                            <tr>
                                <td>${schedule.date}</td>
                                <td>${schedule.day}</td>
                                <td>${schedule.time}</td>
                                <td>
                                    <button class="btn btn-primary btn-sm">
                                        <i class="fas fa-link"></i>
                                    </button>
                                </td>
                            </tr>
                        `;
                    });

                    $('#show-schedule').html(schedule_el);
                } else {
                    $('#show-schedule').html('');
                }

                return true;
            }

            return false;
        };
        
        objects_dynamic_table.addDataToForm = (fields_id_list, imgs_fields, data, prefix) => {
            $('#edit-track_grade_id').empty().trigger('change');
            
            $('#edit-id').val(data.id);

            fields_id_list.forEach(el_id => {
                $(`#${prefix + el_id}`).val(data[el_id]).change();
            });

            if (Boolean(data.days)) {
                $(`#edit-days`).val(data.days.split(',')).change();
            }
            
            if (Boolean(data.grade)) {
                let tmp = new Option(lang == 'ar' ? data.grade.ar_title : data.grade.en_title, data.grade.id, false, true);
                $('#edit-grade_id').append(tmp);
            }  

            if (Boolean(data.meta)) {
                window.setMeta(data.meta);
                $('#edit-meta').trigger('change')
            }
        };

        const init = (() => {
            let lang = "<?php echo e($lang); ?>";
            
            $('#categories, #edit-categories, #s-categories').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Course_Category'); ?>",
                ajax: {
                    url: '<?php echo e(url("admin/course-categories-search")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_name : item.en_name,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#grade_id, #edit-grade_id, #s-grades').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Grade'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.grades")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: data.map(function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title ,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            }).change(function () {
                window.grade_id = $(this).val(); 
                let target = $(this).data('target');
                
                if (window.grade_id != null) {
                    target == '#edit-track_id' 
                        ? $(target).removeAttr('disabled')
                        : $(target).val('').removeAttr('disabled').trigger('change');
                } else {
                    $(target).val('').attr('disabled', 'disabled').trigger('change');
                }
            });

            $('#track_id, #edit-track_id, #s-grades').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Track'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.tracks")); ?>',
                    dataType: 'json',
                    delay: 150,
                    data: function (params) {
                        var query = {
                            q  : params.term,
                            is_sub  : true, 
                            grade_id : window.grade_id
                        }
                        return query;
                    },
                    processResults: function (data) {
                        return {
                            results: data.map(function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title ,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#days, #edit-days, #s-days').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Days'); ?>",
            });

        })();
        
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/grade_groups/index.blade.php ENDPATH**/ ?>