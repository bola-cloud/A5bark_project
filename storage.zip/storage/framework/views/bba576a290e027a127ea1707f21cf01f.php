
<div style="display: none" id="showObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('courses_subscriptions.Show Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#showObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <div class="card my-3">
        <div class="card-header">
            <?php echo app('translator')->get('courses_subscriptions.Students'); ?>
        </div><!-- /.card-header -->
    
        <div class="card-body">
            <table class="table">
                <tr>
                    <td><?php echo app('translator')->get('students.Name'); ?></td>
                    <td id="show-name"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('students.Email'); ?></td>
                    <td id="show-email"></td>
                </tr>
                
                <tr>
                    <td><?php echo app('translator')->get('students.Phone'); ?></td>
                    <td id="show-phone"></td>
                </tr>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->
    
    <div class="card my-3">
        <div class="card-header">
            <?php echo app('translator')->get('courses_subscriptions.Subscription'); ?>
        </div><!-- /.card-header -->
    
        <div class="card-body">
            <table class="table">
                <tr>
                    <td><?php echo app('translator')->get('courses_transacrions.Transaction_Num'); ?></td>
                    <td id="show-transaction_num"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('courses_subscriptions.Payment_Method'); ?></td>
                    <td id="show-payment_method"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('courses_subscriptions.Price'); ?></td>
                    <td id="show-price"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('courses_subscriptions.Status'); ?></td>
                    <td id="show-status"></td>
                </tr>
                
                <tr>
                    <td><?php echo app('translator')->get('courses_subscriptions.Expiry_Date'); ?></td>
                    <td id="show-expiry_date"></td>
                </tr>
                
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->
    
    <div class="card my-3" id="show-course-content">
        <div class="card-header">
            <?php echo app('translator')->get('courses_subscriptions.Course'); ?>
        </div><!-- /.card-header -->
    
        <div class="card-body">
            <table class="table">
                <tr>
                    <td><?php echo app('translator')->get('courses.Title'); ?></td>
                    <td id="show-ar_title"></td>
                    <td id="show-en_title"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('courses.Description'); ?></td>
                    <td id="show-ar_description"></td>
                    <td id="show-en_description"></td>
                </tr>
                
                <tr>
                    <td><?php echo app('translator')->get('courses_subscriptions.Is_Active'); ?></td>
                    <td colspan="2" id="show-is-avilable"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('courses.Trainer'); ?></td>
                    <td colspan="2" id="show-trainer"></td>
                </tr>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->
    
    <div class="card" id="show-grade-content">
        <div class="card-header">
            <?php echo app('translator')->get('grade_groups.Grade'); ?>
        </div><!-- /.card-header -->
    
        <div class="card-body">
            <table class="table">
                <tr>
                    <td><?php echo app('translator')->get('grade_groups.Grade'); ?></td>
                    <td id="show-grade"></td>
                </tr>

                <tr>
                    <td><?php echo app('translator')->get('grade_groups.Group'); ?></td>
                    <td id="show-title"></td>
                </tr>
                
                <tr>
                    <td><?php echo app('translator')->get('grade_groups.Days'); ?></td>
                    <td id="show-days"></td>
                </tr>

                
                <tr>
                    <td><?php echo app('translator')->get('grade_groups.Time'); ?></td>
                    <td id="show-time"></td>
                </tr>
                
                <tr>
                    <td><?php echo app('translator')->get('grade_groups.Number_Of_Sessions'); ?></td>
                    <td id="show-number_of_sessions"></td>
                </tr>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->
</div><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses_subscriptions/incs/_show.blade.php ENDPATH**/ ?>