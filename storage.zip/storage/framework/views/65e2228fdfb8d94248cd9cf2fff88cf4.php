
<div style="display: none" id="showObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('roles.Show Role'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#showObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <div>
        <table class="table">
            <tr>
                <td><?php echo app('translator')->get('roles.Name'); ?></td>
                <td id="show-name"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('roles.Description'); ?></td>
                <td id="show-description"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('roles.Permissions'); ?></td>
                <td id="show-permissions"></td>
            </tr>
        </table>
    </div>

    <h3><?php echo app('translator')->get('roles.Assigned_Users'); ?></h3>
    <div style="height: 300px; overflow-y: scroll">
        <table class="table">
            <tr>
                <td>#</td>
                <td><?php echo app('translator')->get('roles.Name'); ?></td>
                <td><?php echo app('translator')->get('roles.Category'); ?></td>
                <td><?php echo app('translator')->get('roles.Email'); ?></td>
                <td><?php echo app('translator')->get('roles.Phone'); ?></td>
            </tr>
            <tbody id="show-users">

            </tbody>
        </table>
    </div>
</div><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/roles/incs/_show.blade.php ENDPATH**/ ?>