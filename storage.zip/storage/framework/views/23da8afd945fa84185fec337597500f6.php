

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="d-flex justify-content-center blue-color mt-5"> الأخبار </h1>
    <div class="row">
        <br>
        <div class="row mt-5 d-flex">
            <div class="col-md-12">
                <a href="<?php echo e(route('news')); ?>" class="btn btn-outline-primary btn-color m-3 <?php echo e(is_null($selectedCategory) ? 'active' : ''); ?>">الكل</a>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('news.filter', $category->id)); ?>" class="btn btn-outline-primary btn-color m-3 <?php echo e($selectedCategory && $selectedCategory->id == $category->id ? 'active' : ''); ?>">
                        <?php echo e($category->ar_name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    
    <div class="row mb-5">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 mt-5">
            <a href="<?php echo e(route('news_details',$new->id)); ?>">
                <div class="custom-card">
                    <img src="<?php echo e(asset('media/'.$new->image)); ?>" alt="Card image" style="min-height: 31vh;">
                    <div class="card-body">
                        <div class="card-title row">
                            <h5 class="col-md-6 blue-color text-justify"> <?php echo e($new->ar_title); ?> </h5>
                            <div class="time-indicator col-md-6 p-0">
                                <i class="far fa-clock"></i>
                                <span><?php echo e($new->created_at->diffForHumans(null, false, false, 2)); ?></span>
                            </div>
                        </div>
                        <div class="row d-flex flex-row-reverse mb-1 ml-1">
                            <div class="col-md-4 mb-3">
                                <a href="#" class="card-link text-justify">مشاركة</a>
                            </div>
                        </div>
                        <p class="card-text text-justify"> <?php echo e($new->ar_head); ?>  </p>
                    </div>
                    <div class="card-footer">
                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/front/news.blade.php ENDPATH**/ ?>