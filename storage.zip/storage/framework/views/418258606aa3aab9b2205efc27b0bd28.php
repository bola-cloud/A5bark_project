<div style="display: none" id="createObjectCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('grade_groups.Create Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#createObjectCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
        <input type="hidden" id="meta">

        <div class="my-2 row">
            <label for="title" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Title'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input min="1" class="form-control" id="title" placeholder="<?php echo app('translator')->get('grade_groups.Title'); ?>">
                <div style="padding: 5px 7px; display: none" id="titleErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="start_date" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Start_Date'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="date" min="1" class="form-control" id="start_date" placeholder="<?php echo app('translator')->get('grade_groups.Start_Date'); ?>">
                <div style="padding: 5px 7px; display: none" id="start_dateErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="days" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Days'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="days" multiple="multiple">
                    <option value="Sun">Sun</option><option value="Mon">Mon</option>
                    <option value="Tue">Tue</option><option value="Wed">Wed</option>
                    <option value="Thu">Thu</option><option value="Fri">Fri</option>
                    <option value="Sat">Sat</option>
                </select>
                <div style="padding: 5px 7px; display: none" id="daysErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="time" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Time'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="time" class="form-control" id="time">
                <div style="padding: 5px 7px; display: none" id="timeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="number_of_sessions" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Number_Of_Sessions'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="number" class="form-control" id="number_of_sessions">
                <div style="padding: 5px 7px; display: none" id="number_of_sessionsErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="grade_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('grade_groups.Grade'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="grade_id" data-target="#track_id"></select>
                <div style="padding: 5px 7px; display: none" id="grade_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-3 row">
            <div class="col-sm-6" style="height: 250px; overflow-y: scroll">
                <h4>Tracks</h4>
                <div class="list-group" id="create-tracks_list"></div>
            </div><!-- /.col-sm-6 -->

            <div class="col-sm-6">
                <h4>Courses</h4>
                <div class="list-group" id="create-courses_list"></div>
            </div><!-- /.col-sm-6 -->
        </div><!-- /.my-2 -->
        
        <button class="create-object btn btn-primary float-end"><?php echo app('translator')->get('grade_groups.Create Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
$(document).ready(function () {
    const Store = (() => {
        const meta = {
            grade              : null, 
            active_track       : null,
            selected_tracks    : [],
            selected_courses   : {},
            number_of_sessions : 0,
        };

        const helpers = {
            sumTrackNumSession : (track_id, is_add = true) => {
                let number_of_sessions = 0;
                let target_track = meta.grade.tracks.find(track => track.id == track_id);
                
                target_track.courses.forEach(course => {
                    number_of_sessions += course.number_of_sessions;
                });

                meta.number_of_sessions = is_add 
                    ? meta.number_of_sessions + number_of_sessions 
                    : meta.number_of_sessions - number_of_sessions;  
            },

            sumCourseNumSession : (track_id, course_id, is_add = true) => {
                console.log('sumCourseNumSession : ', course_id);
                let target_track  = meta.grade.tracks.find(track => track.id == track_id);
                let target_course = target_track.courses.find(course => course.id == course_id);

                meta.number_of_sessions = is_add 
                    ? meta.number_of_sessions + target_course.number_of_sessions 
                    : meta.number_of_sessions - target_course.number_of_sessions;  
            }
        };

        const setters = {
            fetchGrade : async (grade_id) => {
                let res = await axios.get(`<?php echo e(route('admin.trackGrades.index')); ?>/${grade_id}`);

                let { data, success } = res.data;

                meta.grade = {...data};

                return data;
            },
            
            clearGrade : () => {
                meta.grade              = null;
                meta.active_track       = null;
                meta.selected_tracks    = [];
                meta.selected_courses   = {};
                meta.number_of_sessions = 0
            },

            selectActiveTrack : (track_id) => {
                meta.active_track = track_id
            },

            selectTrack : (track_id, is_selected) => {
                if (is_selected) {
                    meta.selected_tracks.push(track_id);
                    helpers.sumTrackNumSession(track_id, true);
                } else {
                    meta.selected_tracks = meta.selected_tracks.filter(id => id != track_id);
                    meta.selected_courses[track_id] = [];
                    helpers.sumTrackNumSession(track_id, false);
                }
            },

            selectCourse : (track_id, course_id, is_selected) => {
                let track = meta.grade.tracks.find(track => track.id == track_id);

                if (is_selected) {
                    if (Boolean(meta.selected_courses[track_id])) {
                        meta.selected_courses[track_id].push(course_id);
                    } else {
                        meta.selected_courses[track_id] = [course_id];
                    }

                    // if we already selected all courses of the track select the track_id
                    if (track.courses.length == meta.selected_courses[track_id].length) {
                        meta.selected_tracks.push(track_id);  
                        meta.selected_courses[track_id] = [];
                    }

                    helpers.sumCourseNumSession(track_id, course_id, true);
                } else {

                    if (meta.selected_tracks.includes(track.id)) {
                        meta.selected_tracks = meta.selected_tracks.filter(id => id != track.id);
                        
                        meta.selected_courses[track_id] = [];

                        track.courses.forEach(course => {
                            if (course.id != course_id) {
                                meta.selected_courses[track_id].push(course.id);
                            }
                        });
                    } else {
                        meta.selected_courses[track_id].filter(id => id != course_id)
                    }

                    helpers.sumCourseNumSession(track_id, course_id, false);
                }
                
            }

        };

        const getters = {
            getTrack : (track_id) => {
                let track = meta.grade.tracks.find(track => track.id == track_id);
                
                return {...track};
            },

            getTracks : () => {
                return Boolean(meta.grade?.tracks) ? meta.grade.tracks : [];
            },

            getCourses : (track_id) => {
                let target_track = meta.grade.tracks.find(track => track.id == track_id);
                return [...target_track.courses]
            }, 

            getSelectedTracks : () => {
                return [...meta.selected_tracks];
            },

            getSelectedCourses : (track_id) => {
                return Boolean(meta.selected_courses[track_id]) ? [...meta.selected_courses[track_id]] : [];
            },

            getNumberOfSessions : () => {
                return meta.number_of_sessions;
            },

            getMeta : () => {
                return {...meta};
            }
        };

        return {
            setters,
            getters
        };
    })();

    const View = (() => {
        let tracks_list_container   = '#create-tracks_list';
        let courses_list_container  = '#create-courses_list';
        let num_of_sessions_field   = '#number_of_sessions';  
        let meta_field              = '#meta';   

        const renderTracks = (tracks, selected_track_id, selected_tracks = []) => {
            let tracks_els = '';

            tracks.forEach(track => {
                let number_of_sessions = track.courses.map(course => course.number_of_sessions);

                number_of_sessions = number_of_sessions.length ? number_of_sessions.reduce((i, j) => i+j) : 0;

                tracks_els += `
                    <div style="cursor: pointer" data-target="${track.id}" class="${track.id == selected_track_id && 'active'} track-el list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold">${track.ar_title} / ${track.en_title}</div>
                            Number Of Courses : ${track.courses.length}
                            <br/>
                            Number Of Sessions : ${number_of_sessions}
                        </div>
                        
                        <label class="badge bg-primary rounded-pill">
                            select Courses
                            <input data-target="${track.id}" ${selected_tracks.includes(track.id) ? 'checked="checked"' : "" } class="select-track mx-1" type="checkbox">
                        </label>
                    </div>
                `;
            });
            
            $(tracks_list_container).html(tracks_els);
        }

        const renderCourses = (courses, selected_tracks, selected_courses) => {
            let courses_els = '';
            
            courses.forEach(course => {
                courses_els += `
                    <div style="cursor: pointer" data-target="${course.id}" class="course-el list-group-item d-flex justify-content-between align-items-start">
                        <div class="ms-2 me-auto">
                            <div class="fw-bold">${course.ar_title} / ${course.en_title}</div>
                            Number Of Sessions : ${course.number_of_sessions}
                        </div>

                        <label class="badge bg-primary rounded-pill">
                            select Courses
                            <input data-track="${course.track_id}" data-course="${course.id}" class="select-course mx-1" 
                                ${selected_tracks.includes(course.track_id) || (selected_courses.includes(course.id)) ? 'checked="checked"' : ''} 
                                type="checkbox">
                        </label>
                    </div>
                `;
            });

            $(courses_list_container).html(courses_els);
        }

        const renderMetaFields = (meta, number_of_sessions) => {
            $(meta_field).val(JSON.stringify(meta));
            $(num_of_sessions_field).val(number_of_sessions);
        }

        return {
            renderTracks,
            renderCourses,
            renderMetaFields,

            tracks_list_container,
            courses_list_container
        }
    })();

    (() => {
        const { setters, getters } = Store;

        $('#grade_id').on('change', async function () {
            let tracks   = [];
            let grade_id = $(this).val();

            if (Boolean(grade_id)) {
                await setters.fetchGrade(grade_id);
                
                tracks = getters.getTracks();
            } else {
                setters.clearGrade();
            }

            View.renderTracks(tracks);
            View.renderCourses([]);
        });

        $(View.tracks_list_container).on('click', '.track-el', function (e) {
            let track_id = $(this).data('target');
            
            setters.selectActiveTrack(track_id);

            let selected_tracks  = getters.getSelectedTracks();
            let selected_courses = getters.getSelectedCourses(track_id);
            
            View.renderTracks(getters.getTracks(), track_id, selected_tracks);
            View.renderCourses(getters.getCourses(track_id), selected_tracks, selected_courses);

        }).on('click', '.select-track', function (e) {
            let track_id    = $(this).data('target');
            let is_selected = $(this).prop('checked');

            setters.selectTrack(track_id, is_selected);

            View.renderMetaFields(getters.getMeta() ,getters.getNumberOfSessions());
        });

        $(View.courses_list_container).on('click', '.select-course', function () {
            let track_id    = $(this).data('track');
            let course_id   = $(this).data('course');
            let is_selected = $(this).prop('checked');

            setters.selectCourse(track_id, course_id, is_selected);
            
            let selected_tracks  = getters.getSelectedTracks();
            let selected_courses = getters.getSelectedCourses(track_id);
            
            View.renderTracks(getters.getTracks(), track_id, selected_tracks);
            View.renderCourses(getters.getCourses(track_id), selected_tracks, selected_courses);
            
            View.renderMetaFields(getters.getMeta() ,getters.getNumberOfSessions());
        });

        
    })();
});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/grade_groups/incs/_create.blade.php ENDPATH**/ ?>