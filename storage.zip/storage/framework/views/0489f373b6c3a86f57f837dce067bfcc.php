<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Promo Folders'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('promo_codes.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('courses_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.promo_folders.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('promo_codes.Title'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Trainer'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Courses'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Total_Promos'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Used_Promos'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Expiry_Date'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.List_Promos'); ?></th>
                        <th><?php echo app('translator')->get('promo_codes.Download'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody6></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    <?php if($permissions == 'admin' || in_array('promoCodes_add', $permissions)): ?>
        <?php echo $__env->make('admin.promo_folders.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('promoCodes_show', $permissions)): ?>
        <?php echo $__env->make('admin.promo_folders.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('promoCodes_edit', $permissions)): ?>
        <?php echo $__env->make('admin.promo_folders.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
$('document').ready(function () {
    let lang = "<?php echo e($lang); ?>";

    const objects_dynamic_table = new DynamicTable(
        {
            index_route   : "<?php echo e(route('admin.promoFolders.index')); ?>",
            store_route   : "<?php echo e(route('admin.promoFolders.store')); ?>",
            show_route    : "<?php echo e(route('admin.promoFolders.index')); ?>",
            update_route  : "<?php echo e(route('admin.promoFolders.index')); ?>",
            destroy_route : "<?php echo e(route('admin.promoFolders.index')); ?>",
        },
        '#dataTable',
        {
            success_el : '#successAlert',
            danger_el  : '#dangerAlert',
            warning_el : '#warningAlert'
        },
        {
            table_id        : '#dataTable',
            toggle_btn      : '.toggle-btn',
            create_obj_btn  : '.create-object',
            update_obj_btn  : '.update-object',
            fields_list     : [
                'id',
                'title', 'type', 
                'discount_ratio', 'discount_limit', 'expiry_date', 
                'number_of_promos',
                'trainer_id', 'courses',
            ],
            imgs_fields     : []
        },
        [
            { data: 'id',            name: 'id' },
            { data: 'title',         name: 'title' },
            { data: 'trainer',       name: 'trainer' },
            { data: 'courses',       name: 'courses' },
            { data: 'promos_count',  name: 'promos_count' },
            { data: 'used_promos',   name: 'used_promos' },
            { data: 'expiry_date',   name: 'expiry_date' },
            { data: 'list_promos',   name: 'list_promos' },
            { data: 'download',      name: 'download' },
            { data: 'activation',    name: 'activation' },
            { data: 'actions',       name: 'actions' },
        ],
        function (d) {
            if ($('#s-title').length)
            d.title = $('#s-title').val(); 

            if ($('#s-trainers').length)
            d.trainers = $('#s-trainers').val();  
        
            if ($('#s-courses').length)
            d.courses = $('#s-courses').val();  
            
            if ($('#s-is_active').length)
            d.is_active = $('#s-is_active').val(); 
        
            if ($('#s-expiry_date_from').length)
            d.expiry_date_from = $('#s-expiry_date_from').val(); 
        
            if ($('#s-expiry_date_to').length)
            d.expiry_date_to = $('#s-expiry_date_to').val(); 
        }
    );

    objects_dynamic_table.validateData = (data, prefix = '') => {
        // inite validation flag
        let is_valide = true;

        // clear old validation session
        $('.err-msg').slideUp(500);

        if (['null', null, 'undefined', ''].includes(data.get('trainer_id'))) {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.trainer_id is required"); ?>';
            $(`#${prefix}trainer_idErr`).text(err_msg);
            $(`#${prefix}trainer_idErr`).slideDown(500);
        }

        if (data.get('title') === '') {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.title is required"); ?>';
            $(`#${prefix}titleErr`).text(err_msg);
            $(`#${prefix}titleErr`).slideDown(500);
        }
        
        if (data.get('number_of_promos') == '' || Number(data.get('number_of_promos')) <= 0) {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.number_of_promos is required"); ?>';
            $(`#${prefix}number_of_promosErr`).text(err_msg);
            $(`#${prefix}number_of_promosErr`).slideDown(500);
        }

        if (data.get('number_of_promos') == '' || Number(data.get('number_of_promos')) > 5000) {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.number_of_promos is not valied"); ?>';
            $(`#${prefix}number_of_promosErr`).text(err_msg);
            $(`#${prefix}number_of_promosErr`).slideDown(500);
        }

        if (data.get('type') === '') {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.type is required"); ?>';
            $(`#${prefix}typeErr`).text(err_msg);
            $(`#${prefix}typeErr`).slideDown(500);
        } else if (data.get('type') == 'discount') {
            if (data.get('discount_ratio') == '' || data.get('discount_ratio') <= 0) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("promo_codes.discount_ratio is required"); ?>';
                $(`#${prefix}discount_ratioErr`).text(err_msg);
                $(`#${prefix}discount_ratioErr`).slideDown(500);
            }

            if (data.get('discount_ratio') == '' || data.get('discount_ratio') <= 0) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("promo_codes.discount_ratio is required"); ?>';
                $(`#${prefix}discount_ratioErr`).text(err_msg);
                $(`#${prefix}discount_ratioErr`).slideDown(500);
            }
        } else {
            data.delete('discount_ratio')
            data.delete('discount_limit')
        }

        if (data.get('expiry_date') == '') {
            is_valide = false;
            let err_msg = '<?php echo app('translator')->get("promo_codes.expiry_date is required"); ?>';
            $(`#${prefix}expiry_dateErr`).text(err_msg);
            $(`#${prefix}expiry_dateErr`).slideDown(500);
        } else {
            const now_date    = new Date();
            const expiry_date = new Date(data.get('expiry_date'));

            if (expiry_date.getTime() <= now_date.getTime()) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("promo_codes.expiry_date is not valied"); ?>';
                $(`#${prefix}expiry_dateErr`).text(err_msg);
                $(`#${prefix}expiry_dateErr`).slideDown(500);
            }
        }
    
        return is_valide;
    };

    objects_dynamic_table.showDataForm = async (targetBtn) => {
    
        let target_id = $(targetBtn).data('object-id');
        let keys = ['title', 'type', 'discount_ratio', 'discount_limit', 'expiry_date', 'promos_count', 'used_promos'];
        
        let response = await axios.get(`<?php echo e(url('admin/promo-folders')); ?>/${target_id}`);

        let { data, success } = response.data;
        
        if (success) {
            
            $(`#show-id`).val(data.id);

            keys.forEach(key => {
                $(`#show-${key}`).text(Boolean(data[key]) ? data[key] : '---');
            });
            
            $('#show-trainer').text(Boolean(data.trainer) ? Boolean(data.trainer.user.name) : '---');
            
            if (Boolean(data.courses)) {
                let tmp = ``;

                data.courses.forEach(course => {
                    tmp += `<span class="badge bg-primary mx-1">${lang == 'ar' ? course.ar_title : course.en_title}</span>`;
                });

                $('#show-courses').html(Boolean(tmp) ? tmp : '---');
            }

            $('#nav-info-tab').trigger('click');
            
            return true;
        }

        return false;
    };
    
    objects_dynamic_table.addDataToForm = (fields_id_list, imgs_fields, data, prefix) => {
        $('#edit-categories, #edit-trainer_id').empty('disabled').trigger('change');

        fields_id_list = fields_id_list.filter(el_id => !imgs_fields.includes(el_id));
        
        fields_id_list.forEach(el_id => {
            $(`#${prefix + el_id}`).val(data[el_id]).change();
        });
        
        console.log(data);

        if(Boolean(data.trainer)) {
            let tmp = new Option(data.trainer.user.name, data.trainer.user_id, false, true);
            $('#edit-trainer_id').append(tmp);
            $('#edit-trainer_id').removeAttr('disabled').trigger('change');
        }

        if(Boolean(data.courses)) {
            data.courses.forEach(course => {
                let tmp = new Option(`${lang == 'ar' ? course.ar_title : course.en_title }`, course.id, false, true);
                $('#edit-courses').append(tmp);
            });

            $('#edit-courses').removeAttr('disabled').trigger('change');
        }
        
        $('#edit-number_of_promos').val(Boolean(data.promos_count) ? data.promos_count : 0);
        $('#edit-used_promos').val(Boolean(data.used_promos) ? data.used_promos : 0);

    };

    const init = (() => {
        let lang = "<?php echo e($lang); ?>";
        
        $('#categories, #edit-categories, #s-categories').select2({
            allowClear: true,
            width: '100%',
            placeholder: "<?php echo app('translator')->get('layouts.Select_Course_Category'); ?>",
            ajax: {
                url: '<?php echo e(url("admin/course-categories-search")); ?>',
                dataType: 'json',
                delay: 150,
                processResults: function (data) {
                    return {
                        results: $.map(data, function (item) {
                            return {
                                text : lang == 'ar' ? item.ar_name : item.en_name,
                                id   : item.id
                            }
                        })
                    };
                },
                cache: true
            }
        });

        $('#trainer_id, #edit-trainer_id, #s-trainers').select2({
            allowClear: true,
            width: '100%',
            placeholder: "<?php echo app('translator')->get('layouts.Select_Trainer'); ?>",
            ajax: {
                url: '<?php echo e(route("admin.search.trainers")); ?>',
                dataType: 'json',
                delay: 150,
                processResults: function (data) {
                    return {
                        results: $.map(data, function (item) {
                            return {
                                text : `${item.name} - ${item.phone}`,
                                id   : item.id
                            }
                        })
                    };
                },
                cache: true
            }
        });

        $('#courses, #edit-courses, #s-courses').select2({
            allowClear: true,
            width: '100%',
            placeholder: "<?php echo app('translator')->get('layouts.Select_Courses'); ?>",
            ajax: {
                url: '<?php echo e(route("admin.search.courses")); ?>',
                dataType: 'json',
                delay: 150,
                processResults: function (data) {
                    return {
                        results: $.map(data, function (item) {
                            return {
                                text : `${lang == 'ar' ? item.ar_title : item.en_title }`,
                                id   : item.id
                            }
                        })
                    };
                },
                cache: true
            }
        });

    })();
    
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_folders/index.blade.php ENDPATH**/ ?>