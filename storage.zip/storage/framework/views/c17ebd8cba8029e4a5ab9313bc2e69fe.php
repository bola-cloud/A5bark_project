
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses.Name'); ?></label>
            <input type="text" class="form-control" id="s-name">
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses.Trainer'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-trainers"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses.Grade'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-grades"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses.Categories'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-categories"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('layouts.Active'); ?></label>
            <select type="text" class="form-control" id="s-is_active">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="1"><?php echo app('translator')->get('layouts.active'); ?></option>
                <option value="0"><?php echo app('translator')->get('layouts.de-active'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/tracks/incs/_search.blade.php ENDPATH**/ ?>