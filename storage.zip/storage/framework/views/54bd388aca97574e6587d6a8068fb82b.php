
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Title'); ?></label>
            <input type="text" class="form-control" id="s-title">
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Trainer'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-trainers"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Courses'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-courses"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('layouts.Active'); ?></label>
            <select type="text" class="form-control" id="s-is_active">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="1"><?php echo app('translator')->get('layouts.active'); ?></option>
                <option value="0"><?php echo app('translator')->get('layouts.de-active'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Expiry_Date_From'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_from" />
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Expiry_Date_To'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_to" />
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->
</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_folders/incs/_search.blade.php ENDPATH**/ ?>