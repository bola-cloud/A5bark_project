
<div style="display: none" id="showObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('grade_groups.Show Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#showObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <div class="row">
        <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Home</button>
                <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Schedule</button>
            </div><!-- /.nav -->
        </nav>

        <div class="tab-content" id="nav-tabContent">
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                <table class="table">
                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Title'); ?></td>
                        <td class="text-right" id="show-title"></td>
                    </tr>

                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Grade'); ?></td>
                        <td id="show-grade"></td>
                    </tr>

                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Start_Date'); ?></td>
                        <td id="show-start_date"></td>
                    </tr>

                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Time'); ?></td>
                        <td id="show-time"></td>
                    </tr>

                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Days'); ?></td>
                        <td id="show-days"></td>
                    </tr>

                    <tr>
                        <td><?php echo app('translator')->get('grade_groups.Number_Of_Sessions'); ?></td>
                        <td colspan="2" id="show-number_of_sessions"></td>
                    </tr>

                </table>
            </div><!-- /.tab-pane -->

            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab" style="height: 250px; overflow-y: scroll">
                <table class="table text-center">
                    <thead>
                        <tr>
                            <td>Date</td>
                            <td>Day</td>
                            <td>Time</td>
                            <td>Action</td>
                        </tr>
                    </thead>
                    <tbody id="show-schedule"></tbody>
                </table>
            </div><!-- /.tab-pane -->
        </div><!-- /.tab-content -->
    </div><!-- /.row -->
</div><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/grade_groups/incs/_show.blade.php ENDPATH**/ ?>