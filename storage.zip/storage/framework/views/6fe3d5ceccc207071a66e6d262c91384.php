<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Courses Subscriptions'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('courses_subscriptions.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('courseSubscription_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.courses_subscriptions.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('courses_transacrions.Transaction_Num'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Type'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Subscription_For'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Student'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Status'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Payment_Method'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Price'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Created_At'); ?></th>
                        <th><?php echo app('translator')->get('courses_subscriptions.Expiry_Date'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    <?php if($permissions == 'admin' || in_array('courseSubscription_add', $permissions)): ?>
        <?php echo $__env->make('admin.courses_subscriptions.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('courseSubscription_show', $permissions)): ?>
        <?php echo $__env->make('admin.courses_subscriptions.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('document').ready(function () {
        window.lang = "<?php echo e($lang); ?>";

        const objects_dynamic_table = new DynamicTable(
            {
                index_route   : "<?php echo e(route('admin.courseSubscription.index')); ?>",
                store_route   : "<?php echo e(route('admin.courseSubscription.store')); ?>",
                show_route    : "<?php echo e(route('admin.courseSubscription.index')); ?>",
                update_route  : "<?php echo e(route('admin.courseSubscription.index')); ?>",
                destroy_route : "<?php echo e(route('admin.courseSubscription.index')); ?>",
            },
            '#dataTable',
            {
                success_el : '#successAlert',
                danger_el  : '#dangerAlert',
                warning_el : '#warningAlert'
            },
            {
                table_id        : '#dataTable',
                toggle_btn      : '.toggle-btn',
                create_obj_btn  : '.create-object',
                update_obj_btn  : '.update-object',
                fields_list     : [
                    'id', 'course_id', 'student_id', 'payment_method', 'promo_code',
                    'subscription_type', 'group_id', 'plan_id'
                ],
                imgs_fields     : []
            },
            [
                { data: 'id',                 name: 'id' },
                { data: 'transaction_num',    name: 'transaction_num' },
                { data: 'subscription_type',  name: 'subscription_type' },
                { data: 'subscription_for',   name: 'subscription_for' },
                { data: 'student',            name: 'student' },
                // { data: 'grade',              name: 'grade' },
                // { data: 'trainer',            name: 'trainer' },
                { data: 'status',             name: 'status' },
                { data: 'payment_method',     name: 'payment_method' },
                { data: 'price',              name: 'price' },
                { data: 'created_at',         name: 'created_at' },
                { data: 'expiry_date',        name: 'expiry_date' },
                { data: 'activation',         name: 'activation' },
                { data: 'actions',            name: 'actions' },
            ],
            function (d) {
                
                if ($('#s-transaction_num').length)
                d.transaction_num = $('#s-transaction_num').val(); 
                
                if ($('#s-students').length)
                d.students = $('#s-students').val(); 

                if ($('#s-grades').length)
                d.grades = $('#s-grades').val();  
                
                // if ($('#s-trainers').length)
                // d.trainers = $('#s-trainers').val(); 
                
                if ($('#s-status').length)
                d.status = $('#s-status').val(); 
                
                if ($('#s-payment_method').length)
                d.payment_method = $('#s-payment_method').val();  
                
                if ($('#s-courses').length)
                d.courses = $('#s-courses').val();  
                
                if ($('#s-subscription_type').length)
                d.subscription_type = $('#s-subscription_type').val(); 

                if ($('#s-is_active').length)
                d.is_active = $('#s-is_active').val(); 
                
                if ($('#s-created_at_from').length)
                d.created_at_from = $('#s-created_at_from').val(); 
            
                if ($('#s-created_at_to').length)
                d.created_at_to = $('#s-created_at_to').val();

                if ($('#s-expiry_date_from').length)
                d.expiry_date_from = $('#s-expiry_date_from').val(); 
            
                if ($('#s-expiry_date_to').length)
                d.expiry_date_to = $('#s-expiry_date_to').val();

            },
            custome_msg = {
                delete_msg : `<?php echo app('translator')->get("courses_subscriptions.confirm_cancel"); ?>`
            }
        );

        objects_dynamic_table.validateData = (data, prefix = '') => {
            // inite validation flag
            let is_valide = true;

            // clear old validation session
            $('.err-msg').slideUp(500);

            if (!['course', 'grade'].includes(data.get('subscription_type'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses_subscriptions.required_subscription_type"); ?>';
                $(`#${prefix}subscription_typeErr`).text(err_msg);
                $(`#${prefix}subscription_typeErr`).slideDown(500);
            }

            if (data.get('subscription_type') == 'course') {
                
                if (['', null, 'null', 'undefined'].includes(data.get('course_id'))) {
                    is_valide = false;
                    let err_msg = '<?php echo app('translator')->get("courses_subscriptions.course_id is required"); ?>';
                    $(`#${prefix}course_idErr`).text(err_msg);
                    $(`#${prefix}course_idErr`).slideDown(500);
                }

                data.delete('plan_id');
                data.delete('group_id');
            } else if (data.get('subscription_type') == 'grade') {
                if (data.get('subscription_type') == 'grade' && data.get('plan_id') == '') {
                    is_valide = false;
                    let err_msg = '<?php echo app('translator')->get("courses_subscriptions.plan is not valied"); ?>';
                    $(`#${prefix}plan_idErr`).text(err_msg);
                    $(`#${prefix}plan_idErr`).slideDown(500);
                }

                if (data.get('subscription_type') == 'grade' && data.get('group_id') == '') {
                    is_valide = false;
                    let err_msg = '<?php echo app('translator')->get("courses_subscriptions.group_id is required"); ?>';
                    $(`#${prefix}group_idErr`).text(err_msg);
                    $(`#${prefix}group_idErr`).slideDown(500);
                }
                
                data.delete('course_id');
            }

            if (['', null, 'null', 'undefined'].includes(data.get('student_id'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses_subscriptions.student_id is required"); ?>';
                $(`#${prefix}student_idErr`).text(err_msg);
                $(`#${prefix}student_idErr`).slideDown(500);
            }

            if (data.get('payment_method') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses_subscriptions.payment_method is required"); ?>';
                $(`#${prefix}payment_methodErr`).text(err_msg);
                $(`#${prefix}payment_methodErr`).slideDown(500);
            }

            if (data.get('payment_method') == 'promo-code' && data.get('promo_code') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("courses_subscriptions.promo_code is required"); ?>';
                $(`#${prefix}promo_codeErr`).text(err_msg);
                $(`#${prefix}promo_codeErr`).slideDown(500);
            }

            return is_valide;
        };

        objects_dynamic_table.showDataForm = async (targetBtn) => {
        
            let target_user = $(targetBtn).data('object-id');
            
            
            let student_keys     = ['name', 'email', 'phone'];
            let course_keys      = ['ar_title', 'en_title', 'ar_description', 'en_description'];
            let group_keys       = ['title', 'days', 'title', 'days', 'time', 'number_of_sessions'];
            let transaction_keys = ['payment_method', 'status', 'transaction_num', 'price'];
            
            let response = await axios.get(`<?php echo e(route('admin.courseSubscription.index')); ?>/${target_user}`);

            let { data, success } = response.data;

            console.log('data : ', data);
            
            if (success) {
                if (Boolean(data?.student?.user)) {
                    let user = data.student.user;
                    student_keys.forEach(key => {
                        $(`#show-${key}`).text(Boolean(user[key]) ? user[key] : '---');
                    });

                }

                if (data.subscription_type == 'course') {
                    console.log('');
                    $('#show-grade-content').hide();
                    $('#show-course-content').show();
                    
                    let course = data.course;

                    course_keys.forEach(key => {
                        $(`#show-${key}`).text(Boolean(course[key]) ? course[key] : '---');
                    });

                    $('#show-is-avilable').html(course.is_active ? `<span class="badge bg-success">Active</span>` : `<span class="badge bg-danger">Disabled</span>`);

                    $('#show-trainer').text(Boolean(course.trainer) ? course.trainer.name : '---');
                } 

                if (data.subscription_type == 'grade') {
                    $('#show-grade-content').show();
                    $('#show-course-content').hide();
                    
                    let group = data.group;
                    let grade = group.grade;

                    group_keys.forEach(key => {
                        $(`#show-${key}`).text(Boolean(group[key]) ? group[key] : '---');
                    });

                    $('#show-grade').text(Boolean(grade) ? `${grade.ar_title} / ${grade.en_title}` : '---');
                } 
                
                transaction_keys.forEach(key => {
                    let transaction = data.subscription_type == 'grade' ? data.grade_transaction : data.course_transaction;
                    $(`#show-${key}`).text(Boolean(transaction[key]) ? transaction[key] : '---');
                });

                $('#show-expiry_date').text(data.expiry_date ? data.expiry_date : '---');

                return true;
            }

            return false;
        };
        
        

        const init = (() => {
            window.lang = "<?php echo e($lang); ?>";
            
            $('#s-trainers').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Trainer'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.trainers")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : item.name,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#course_id, #edit-course_id, #s-courses').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Course'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.courses")); ?>',
                    dataType: 'json',
                    delay: 150,
                    data: function (params) {
                        var query = {
                            q          : params.term,
                            is_active  : 1
                        }
                        return query;
                    },
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#student_id, #edit-student_id, #s-students').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Student'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.students")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : `${item.name} - ${item.phone} - ${item.email}`,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#grade_id, #edit-grade_id, #s-grades').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('tracks.Select Grade'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.grades")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: data.map(function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title ,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

        })();
        
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses_subscriptions/index.blade.php ENDPATH**/ ?>