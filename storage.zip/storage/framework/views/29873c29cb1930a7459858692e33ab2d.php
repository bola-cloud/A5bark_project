<div class="d-flex justify-content-center">
    <?php if(sizeof($row_object->roles)): ?>
        <?php $__currentLoopData = $row_object->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <span class="badge rounded-pill bg-primary mx-1"><?php echo e($role->display_name); ?></span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?> 
        <span>---</span>
    <?php endif; ?>
</div><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/users/incs/_roles.blade.php ENDPATH**/ ?>