
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    
    <div class="col-md-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_transacrions.Transaction_Num'); ?></label>
            <input type="text"  class="form-control" id="s-transaction_num" />
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-3 -->

    <div class="col-md-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Students'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-students"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-3 -->
    
    <div class="col-md-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Status'); ?></label>
            <select type="text" class="form-control" id="s-status">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="active">active</option>
                <option value="canceled">canceled</option>
                <option value="paused">paused</option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-3 -->
    
    <div class="col-md-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Payment_Method'); ?></label>
            <select type="text" class="form-control" id="s-payment_method">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="promo-code"><?php echo app('translator')->get('courses_subscriptions.promo_code'); ?></option>
                <option value="wallet"><?php echo app('translator')->get('courses_subscriptions.wallet'); ?></option>
                <option value="free"><?php echo app('translator')->get('courses_subscriptions.free'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-3 -->
    
    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Courses'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-courses"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->
    
    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Grades'); ?></label>
            <select type="text" multiple="multiple" class="form-control" id="s-grades"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->

    

    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('layouts.Active'); ?></label>
            <select type="text" class="form-control" id="s-is_active">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="1"><?php echo app('translator')->get('layouts.active'); ?></option>
                <option value="0"><?php echo app('translator')->get('layouts.de-active'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->
    
    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Subscription_Type'); ?></label>
            <select type="text" class="form-control" id="s-subscription_type">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="course"><?php echo app('translator')->get('courses_subscriptions.courses'); ?></option>
                <option value="grade"><?php echo app('translator')->get('courses_subscriptions.grades'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->

    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Created_At_From'); ?></label>
            <input type="date" class="form-control" id="s-created_at_from">
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->
    
    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Created_At_To'); ?></label>
            <input type="date" class="form-control" id="s-created_at_to">
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->

    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Expiry_Date_From'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_from">
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->
    
    <div class="col-md-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('courses_subscriptions.Expiry_Date_To'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_to">
        </div><!-- /.my-2 -->
    </div><!-- /.col-md-6 -->

</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/courses_subscriptions/incs/_search.blade.php ENDPATH**/ ?>