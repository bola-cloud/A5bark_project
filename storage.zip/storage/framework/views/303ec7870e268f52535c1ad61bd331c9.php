
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('users.Name'); ?></label>
            <input type="text" class="form-control" id="s-name">
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->
    
    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('users.Email'); ?></label>
            <input type="text" class="form-control" id="s-email">
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->

    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('users.Phone'); ?></label>
            <input type="text" class="form-control" id="s-phone">
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->

    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('users.Category'); ?></label>
            <select type="text" class="form-control" id="s-category">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="admin"><?php echo app('translator')->get('layouts.admin'); ?></option>
                <option value="technical"><?php echo app('translator')->get('layouts.technical'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->

    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('layouts.Active'); ?></label>
            <select type="text" class="form-control" id="s-is_active">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="1"><?php echo app('translator')->get('layouts.active'); ?></option>
                <option value="0"><?php echo app('translator')->get('layouts.de-active'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->

    <div class="col-4">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('users.Roles'); ?></label>
            <select type="text" class="form-control" id="s-roles" multiple="multiple">
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->

</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/users/incs/_search.blade.php ENDPATH**/ ?>