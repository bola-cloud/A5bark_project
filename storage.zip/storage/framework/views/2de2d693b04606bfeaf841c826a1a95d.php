
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Promo_Folders'); ?></label>
            <select multiple="multiple" class="form-control" id="s-promo_folders"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->
    
    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Code'); ?></label>
            <input multiple="multiple" class="form-control" id="s-code">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Title'); ?></label>
            <input type="text" class="form-control" id="s-title">
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Trainer'); ?></label>
            <select multiple="multiple" class="form-control" id="s-trainers"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->
    
    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Courses'); ?></label>
            <select multiple="multiple" class="form-control" id="s-courses"></select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-3">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Type'); ?></label>
            <select type="text" class="form-control" id="s-type">
                <option value=""><?php echo app('translator')->get('layouts.all'); ?></option>
                <option value="free"><?php echo app('translator')->get('promo_codes.free'); ?></option>
                <option value="discount"><?php echo app('translator')->get('promo_codes.discount'); ?></option>
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-3 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Expiry_Date_From'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_from" />
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-6">
        <div class="my-2 search-action">
            <label for=""><?php echo app('translator')->get('promo_codes.Expiry_Date_To'); ?></label>
            <input type="date" class="form-control" id="s-expiry_date_to" />
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->
</div><!-- /.row --> 
<!-- END   SEARCH BAR --><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_codes/incs/_search.blade.php ENDPATH**/ ?>