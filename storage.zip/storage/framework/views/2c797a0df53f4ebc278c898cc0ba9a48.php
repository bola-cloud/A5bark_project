

<?php $__env->startSection('content'); ?>
<style>
.icons a.btn{
  margin: 0;
}
.card-img-top{
  height: 50vh !important;
}
</style>

<div class="container-fluid mt-5 mb-5">
  <div class="banner">
      <div class="header d-flex justify-content-center">
        <h1 class="d-flex justify-content-center blue-color"> بودكاست </h1>  
      </div>
      <div class="row">
        <div class="col-md-12">
          <img src="<?php echo e(asset('images/صور/New folder/Rectangle 3520.png')); ?>" alt="Podcast Banner" class="w-100">
        </div>
      </div>
      <div class="overlay-text">
        <h1> جيل جديد أفضل مكان للاستماع إلى البودكاست </h1> 
      </div>
  </div>
  <div class="card-footer d-flex p-5">
    <a href="#" class="card-link active" data-target="#playlists"><i class="fas fa-list"></i> قوائم التشغيل</a>
    <a href="#" class="card-link" data-target="#episodes"><i class="fas fa-play-circle"></i> الحلقات</a>
  </div>
  <div class="content " id="episodes">
    <!-- Content for episodes goes here -->
    <div class="container-fluid mt-5">
      <div class="row d-flex justify-content-center">
        <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-3">
            <a href="">
              <div class="custom-card" style="min-width: 45vh;">
                <?php
                    if (!function_exists('getYouTubeVideoId')) {
                        function getYouTubeVideoId($url) {
                            if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
                                preg_match('/(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches);
                                return $matches[1] ?? null;
                            }
                            return null;
                        }
                    }

                    $videoUrl = $episode->video;
                    $videoId = getYouTubeVideoId($videoUrl);
                ?>

                <?php if($videoId): ?>
                    <!-- Display YouTube video -->
                    <iframe src="https://www.youtube.com/embed/<?php echo e($videoId); ?>" frameborder="0" allowfullscreen></iframe>
                <?php else: ?>
                    <!-- Display video from other sources -->
                    <iframe src="<?php echo e($videoUrl); ?>" frameborder="0" allowfullscreen></iframe>
                <?php endif; ?>

                
                <div class="card-body">
                    <div class="card-title row">
                        <h5 class="col-md-6 d-flex text-danger"> الحلقة :<?php echo e($episode->number); ?></h5>
                        <div class="time-indicator col-md-6 d-flex justify-content-end">
                            <i class="far fa-clock"></i>
                            <span><?php echo e($episode->time); ?></span>
                        </div>
                    </div>
                    <div class="row d-flex flex-row-reverse justif-content-between mb-1 ml-1">
                        <div class="col-md-6">
                            <a href="#" class="card-link blue-color">مشاركة</a>
                        </div>
                        <div class="col-md-6 d-flex ">
                          <h4 class="blue-color"> <?php echo e($episode->ar_title); ?> </h4>
                        </div>
                    </div>
                    <p class="card-text text-justify"><?php echo e($episode->ar_description); ?></p>
                </div>
                <div class="card-footer d-flex row">
                  <div class="col-md-12 d-flex flex-wrap">
                    <p href="#" class="card-link text-danger mt-3">استمع على:</p>
                    <p class="d-flex icons mt-3">
                      <a class="btn" href="<?php echo e($episode->tiktok_link); ?>"><i class="fab fa-tiktok"></i></a>
                      <a class="btn" href="<?php echo e($episode->spotify_link); ?>"><i class="fab fa-spotify"></i></a>
                      <a class="btn" href="<?php echo e($episode->youtube_link); ?>"><i class="fab fa-youtube"></i></a>
                      <a class="btn" href="<?php echo e($episode->sound_link); ?>"><i class="fab fa-soundcloud"></i></a>
                    </p>
                    <button class="btn"><i class="fas fa-share-alt"></i> مشاركة </button>
                  </div>
                </div>
              </div>
            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <div class="content active" id="playlists">
    <!-- Content for playlists goes here -->
   
    <div class="container-fluid mt-5 p-5">
      <div class="row">
        <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 mt-4">
            <a href="<?php echo e(route('episodes',$playlist)); ?>">
              <div class="card">
                <img src="<?php echo e(asset('media/'.$playlist->image)); ?>" class="card-img-top w-100 h-100" alt="Podcast Image">
                <div class="card-body">
                  <div class="row justify-content-between">
                    <h5 class="card-title col-md-5 d-flex justify-content-start"> <?php echo e($playlist->ar_title); ?></h5>
                    <ul class="list-group list-group-flush col-md-5">
                      <h5 class="d-flex justify-content-end ml-3">
                          <span class="mr-2 ml-2">8</span>
                          <span> حلقات  <i class="fas fa-list"></i> </span>
                      </h5>
                    </ul>
                  </div>
                    
                </div>
              
                <div class="card-footer d-flex justify-content-between">
                  <p href="#" class="card-link text-danger">استمع على:</p>
                  <div>
                    <a class="btn" href="<?php echo e($playlist->tiktok_link); ?>"><i class="fab fa-tiktok"></i></a>
                    <a class="btn" href="<?php echo e($playlist->spotify_link); ?>"><i class="fab fa-spotify"></i></a>
                    <a class="btn" href="<?php echo e($playlist->youtube_link); ?>"><i class="fab fa-youtube"></i></a>
                    <a class="btn" href="<?php echo e($playlist->sound_link); ?>"><i class="fab fa-soundcloud"></i></a>
                  </div>
                  <button class="btn"><i class="fas fa-share-alt"></i> مشاركة </button>
                </div>
              </div>
            </a>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <div class="row d-flex justify-content-center mt-5" style="direction: ltr;">
        <?php echo e($playlists->links()); ?>

      </div>
    </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function(){
    $('.card-link').on('click', function(e) {
      e.preventDefault();
      $('.card-link').removeClass('active');
      $(this).addClass('active');
      $('.content').removeClass('active');
      $($(this).data('target')).addClass('active');
    });
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/front/podcast.blade.php ENDPATH**/ ?>