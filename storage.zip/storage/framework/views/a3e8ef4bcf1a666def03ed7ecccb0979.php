

<?php $__env->startSection('content'); ?>
<style>
    .icons a.btn{
  margin: 0;
}
</style>
<div class="container-fluid mt-5 mb-5">
    <div class="banner">
        <div class="header d-flex justify-content-center">
          <h1 class="d-flex justify-content-center blue-color"> <?php echo e($playlist->ar_title); ?> </h1>  
        </div>
        <div class="row d-flex justify-content-center">
          <div class="col-md-12 d-flex justify-content-center">
            <img src="<?php echo e(asset('media/'.$playlist->image)); ?>" alt="Podcast Banner" class="w-75">
          </div>
        </div>
    </div>
    <div class="container-fluid mt-5">
        <div class="row d-flex justify-content-center">
          <?php $__currentLoopData = $episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
              <a href="">
                <div class="custom-card" style="min-width: 45vh;">
                  <?php
                    // Function to check if the URL is a YouTube URL and extract the video ID
                    function getYouTubeVideoId($url) {
                        if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) {
                            preg_match('/(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $url, $matches);
                            return $matches[1] ?? null;
                        }
                        return null;
                    }

                    $videoUrl = $episode->video;
                    $videoId = getYouTubeVideoId($videoUrl);
                  ?>

                  <?php if($videoId): ?>
                      <!-- Display YouTube video -->
                      <iframe src="https://www.youtube.com/embed/<?php echo e($videoId); ?>" class="w-100 h-100"
                      style="min-height: 30vh;" frameborder="0" allowfullscreen></iframe>
                  <?php else: ?>
                      <!-- Display video from other sources -->
                      <iframe src="<?php echo e($videoUrl); ?>" frameborder="0" allowfullscreen></iframe>
                  <?php endif; ?>
                  
                  <div class="card-body">
                      <div class="card-title row">
                          <h5 class="col-md-6 d-flex text-danger"> الحلقة :<?php echo e($episode->number); ?></h5>
                          <div class="time-indicator col-md-6 d-flex justify-content-end">
                              <i class="far fa-clock"></i>
                              <span><?php echo e($episode->time); ?></span>
                          </div>
                      </div>
                      <div class="row d-flex flex-row-reverse justif-content-between mb-1 ml-1">
                          <div class="col-md-6">
                              <a href="#" class="card-link blue-color">مشاركة</a>
                          </div>
                          <div class="col-md-6 d-flex ">
                            <h4 class="blue-color"> <?php echo e($episode->ar_title); ?> </h4>
                          </div>
                      </div>
                      <p class="card-text text-justify"><?php echo e($episode->ar_description); ?></p>
                  </div>
                  <div class="card-footer d-flex row">
                    <div class="col-md-12 d-flex flex-wrap">
                      <p href="#" class="card-link text-danger mt-3">استمع على:</p>
                      <p class="d-flex icons mt-3">
                        <a class="btn" href="<?php echo e($episode->tiktok_link); ?>"><i class="fab fa-tiktok"></i></a>
                        <a class="btn" href="<?php echo e($episode->spotify_link); ?>"><i class="fab fa-spotify"></i></a>
                        <a class="btn" href="<?php echo e($episode->youtube_link); ?>"><i class="fab fa-youtube"></i></a>
                        <a class="btn" href="<?php echo e($episode->sound_link); ?>"><i class="fab fa-soundcloud"></i></a>
                      </p>
                      <button class="btn"><i class="fas fa-share-alt"></i> مشاركة </button>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row d-flex justify-content-center mt-5" style="direction: ltr;">
          <?php echo e($episodes->links()); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/front/episodes.blade.php ENDPATH**/ ?>