<div style="display: none" id="editObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('courses.Update Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#editObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>

    <form action="/" id="objectForm">
        <input type="hidden" id="edit-id">
        
        <div class="my-2 row">
            <label for="edit-trainer_id" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Trainer'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="edit-trainer_id"></select>
                <div style="padding: 5px 7px; display: none" id="edit-trainer_idErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="edit-title" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Title'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input class="form-control" id="edit-title" placeholder="<?php echo app('translator')->get('promo_codes.Title'); ?>">
                <div style="padding: 5px 7px; display: none" id="edit-titleErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row">
            <label for="edit-number_of_promos" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Number_Of_Promos'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-4">
                <input type="number" class="form-control" min="1" max="5000" id="edit-number_of_promos" />
                <div style="padding: 5px 7px; display: none" id="edit-number_of_promosErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <label for="edit-used_promos" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Used_Promos'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-4">
                <input type="number" disabled="disabled" class="form-control" min="1" max="100" id="edit-used_promos" />
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="edit-courses" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Courses'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select multiple="multiple" class="form-control" id="edit-courses"></select>
                <div style="padding: 5px 7px; display: none" id="edit-coursesErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="edit-expiry_date" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Expiry_Date'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <input type="date" class="form-control" id="edit-expiry_date" />
                <div style="padding: 5px 7px; display: none" id="edit-expiry_dateErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row">
            <label for="edit-type" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Type'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-10">
                <select class="form-control" id="edit-type">
                    <option value=""><?php echo app('translator')->get('promo_codes.select_type'); ?></option>
                    <option value="free"><?php echo app('translator')->get('promo_codes.free'); ?></option>
                    <option value="discount"><?php echo app('translator')->get('promo_codes.discount'); ?></option>
                </select>
                <div style="padding: 5px 7px; display: none" id="edit-typeErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
        </div><!-- /.my-2 -->
        
        <div class="my-2 row edit-promo-type edit-is-discount" style="display: none">
            <label for="edit-discount_ratio" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Discount_Ratio'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" min="1" max="100" id="edit-discount_ratio" />
                <div style="padding: 5px 7px; display: none" id="edit-discount_ratioErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 pt-1">
                <span class="badge text-bg-primary fs-6">%</span>
            </div>
        </div><!-- /.my-2 -->

        <div class="my-2 row edit-promo-type edit-is-discount" style="display: none">
            <label for="edit-discount_limit" class="col-sm-2 col-form-label"><?php echo app('translator')->get('promo_codes.Discount_Limit'); ?> <span class="text-danger float-right">*</span></label>
            <div class="col-sm-9">
                <input type="number" class="form-control" min="1" max="100" id="edit-discount_limit" />
                <div style="padding: 5px 7px; display: none" id="edit-discount_limitErr" class="err-msg mt-2 alert alert-danger">
                </div>
            </div>
            <div class="col-sm-1 pt-1">
                <span class="badge text-bg-primary fs-6"><?php echo e(ENV('APP_CURRENCY')); ?></span>
            </div>
        </div><!-- /.my-2 -->
        
        <button class="update-object btn btn-warning float-end"><?php echo app('translator')->get('courses.Update Title'); ?></button>
    </form>
</div>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('#edit-type').change(function () {
        let val = $(this).val();

        if (val == 'discount') {
            $('.edit-is-discount').slideDown(500);
        } else {
            $('.edit-promo-type').slideUp(500);
        }

    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_folders/incs/_edit.blade.php ENDPATH**/ ?>