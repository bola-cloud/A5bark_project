<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Dashboard'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-3">
            <div class="rounded-1 p-3 mb-2 bg-primary text-white">
                <i class="fas fa-users fa-3x"></i>    
                <span class="fs-2 float-end" id="stat-clients">
                    <span style="display: none" class="count"></span>

                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </span>
                <hr/>

                <a class=" text-white" href="<?php echo e(route('admin.students.index')); ?>"><?php echo app('translator')->get('layouts.Students'); ?></a>
            </div>
        </div><!-- /.col-md-3 -->
        
        <div class="col-md-3">
            <div class="rounded-1 p-3 mb-2 bg-primary text-white">
                <i class="fas fa-user-tie fa-3x"></i> 
                <span class="fs-2 float-end" id="stat-workShopManagers">
                    <span style="display: none" class="count"></span>

                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </span>
                <hr/>

                <a class=" text-white" href="<?php echo e(route('admin.trainers.index')); ?>"><?php echo app('translator')->get('layouts.Trainers'); ?></a>
            </div>
        </div><!-- /.col-md-3 -->

        <div class="col-md-3">
            <div class="rounded-1 p-3 mb-2 bg-primary text-white">
                <i class="fas fa-chalkboard-teacher fa-3x"></i> 
                <span class="fs-2 float-end" id="stat-workShops">
                    <span style="display: none" class="count"></span>

                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </span>
                <hr/>

                <a class=" text-white" href="<?php echo e(route('admin.courses.index')); ?>"><?php echo app('translator')->get('layouts.Courses'); ?></a>
            </div>
        </div><!-- /.col-md-3 -->

        
        <div class="col-md-3">
            <div class="rounded-1 p-3 mb-2 bg-primary text-white">
                <i class="fas fa-shopping-cart fa-3x"></i> 
                <span class="fs-2 float-end" id="stat-workShops">
                    <span style="display: none" class="count"></span>

                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </span>
                <hr/>

                <a class=" text-white" href="<?php echo e(route('admin.courseSubscription.index')); ?>"><?php echo app('translator')->get('dashboard.Courses_Subscriptipons'); ?></a>
            </div>
        </div><!-- /.col-md-3 -->

        
    </div><!-- /.row -->

    <hr/>

    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
$('document').ready(function () {
    /**
    const renderStatistics = async () => {
        const target_el = ['clients', 'workShops', 'workshopOrders', 'workShopManagers'];

        const res = await axios.get(`<?php echo e(route('admin.dashboard.index')); ?>?get_counts=true`);

        const { data, success } = res.data;
        
        if (success) {
            target_el.forEach(el => {
                $(`#stat-${el}`).find('.spinner-border').hide(500);
                $(`#stat-${el}`).find('.count').text(data[el]).hide(500).show(500);
            });

            $('#workshops-count').text(data.workShops);
        }
    }

    const inite = (() => {
        renderStatistics();
    })();
    */
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>