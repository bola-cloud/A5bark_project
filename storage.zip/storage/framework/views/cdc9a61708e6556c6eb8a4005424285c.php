

<?php $__env->startSection('content'); ?>

<div class="container-fluid p-0 container-padding section-background">
    <!-- Adv Section -->
    <div class="adv-section section-bakground">
        <div class="row">
            <div class="col-md-12">
                <h1 class="text-center mb-3"> اعلان </h1>
                <div class="row">
                    <div class="col-md-12">
                        <img src="<?php echo e(asset('images/صور/New folder/Rectangle 4498.png')); ?>" alt="Sports" class="w-100">
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="text-center blue-color"> Lorem ipsum dolor sit amet consectetur. </h1> <br>
                        <div class="container-padding">
                            <p class="padding-parag">
                                Lorem ipsum dolor sit amet consectetur. Sapien rhoncus ipsum adipiscing tellus sed.
                                Amet libero aliquam pulvinar sit sit donec amet elit aliquet. A sagittis sit at elementum id.
                                Augue ut pellentesque in sodales nam nullam ac.
    
                                Lorem ipsum dolor sit amet consectetur.
                                Sapien rhoncus ipsum adipiscing tellus sed.
                                Amet libero aliquam pulvinar sit sit donec amet elit aliquet.
                                A sagittis sit at elementum id. Augue ut pellentesque in sodales nam nullam ac.
    
                                Lorem ipsum dolor sit amet consectetur. 
                                Sapien rhoncus ipsum adipiscing tellus sed. 
                                Amet libero aliquam pulvinar sit sit donec amet elit aliquet. 
                                A sagittis sit at elementum id. Augue ut pellentesque in sodales nam nullam ac.
    
                            </p>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\A5bark_dashboard\resources\views/front/adverticement.blade.php ENDPATH**/ ?>