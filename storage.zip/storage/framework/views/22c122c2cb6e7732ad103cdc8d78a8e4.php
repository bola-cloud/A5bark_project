<div class="d-flex justify-content-center">
	<?php if($permissions == 'admin' || in_array('districts_edit', $permissions)): ?>
	<div class="form-check form-switch">
		<input class="c-activation-btn form-check-input" id="customSwitch<?php echo e($row_object->id); ?>" data-target-obj="<?php echo e($row_object->id); ?>" type="checkbox" <?php if($row_object->is_active): ?> checked="true" <?php endif; ?>>
		<label class="form-check-label" for="customSwitch<?php echo e($row_object->id); ?>"></label>
	</div>
	<?php else: ?> 
	<?php echo $row_object->is_active ? '<span class="badge bg-primary">active</span>' : '<span class="badge bg-warning">de-active</span>'; ?>

	<?php endif; ?>
</div>
<?php /**PATH C:\Bola\A5bark_dashboard\resources\views/admin/event/incs/_active.blade.php ENDPATH**/ ?>