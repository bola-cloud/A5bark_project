
<div style="display: none" id="showObjectsCard" class="card card-body">
    <div class="row">
        <div class="col-6">
            <h5><?php echo app('translator')->get('promo_codes.Show Title'); ?></h5>
        </div>
        <div class="col-6 text-end">
            <div class="toggle-btn btn btn-outline-dark btn-sm" data-current-card="#showObjectsCard" data-target-card="#objectsCard">
                <i class="fas fa-times"></i>
            </div>
        </div>
    </div><!-- /.row -->
    <hr/>
    
    <div class="card card-body">
        <table class="table">
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Title'); ?></td>
                <td id="show-title"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Type'); ?></td>
                <td id="show-type"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Discount_Ratio'); ?></td>
                <td id="show-discount_ratio"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Discount_Limit'); ?></td>
                <td id="show-discount_limit"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Expiry_Date'); ?></td>
                <td id="show-expiry_date"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Trainer'); ?></td>
                <td id="show-trainer"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Total_Promos'); ?></td>
                <td id="show-promos_count"></td>
            </tr>
            <tr>
                <td><?php echo app('translator')->get('promo_codes.Used_Promos'); ?></td>
                <td id="show-used_promos"></td>
            </tr>
        </table>
    </div><!-- /.card -->

</div>


<?php $__env->startPush('custome-js'); ?>
<?php $__env->stopPush(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/promo_folders/incs/_show.blade.php ENDPATH**/ ?>