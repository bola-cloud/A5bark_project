<?php $__env->startPush('custome-plugin'); ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Track Grades'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('track_grades.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('trackGrades_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.track_grades.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('track_grades.Ar age from'); ?></th>
                        <th><?php echo app('translator')->get('track_grades.En age from'); ?></th>
                        <th><?php echo app('translator')->get('track_grades.Ar age to'); ?></th>
                        <th><?php echo app('translator')->get('track_grades.En age to'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    
    <?php if($permissions == 'admin' || in_array('trackGrades_add', $permissions)): ?>
        <?php echo $__env->make('admin.track_grades.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
        
    <?php if($permissions == 'admin' || in_array('trackGrades_show', $permissions)): ?>
        <?php echo $__env->make('admin.track_grades.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> 
    
    <?php if($permissions == 'admin' || in_array('trackGrades_edit', $permissions)): ?>
        <?php echo $__env->make('admin.track_grades.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('document').ready(function () {
            
        const objects_dynamic_table = new DynamicTable(
            {
                index_route   : "<?php echo e(route('admin.trackGrades.index')); ?>",
                store_route   : "<?php echo e(route('admin.trackGrades.store')); ?>",
                show_route    : "<?php echo e(route('admin.trackGrades.index')); ?>",
                update_route  : "<?php echo e(route('admin.trackGrades.index')); ?>",
                destroy_route : "<?php echo e(route('admin.trackGrades.index')); ?>",
            },
            '#dataTable',
            {
                success_el : '#successAlert',
                danger_el  : '#dangerAlert',
                warning_el : '#warningAlert'
            },
            {
                table_id        : '#dataTable',
                toggle_btn      : '.toggle-btn',
                create_obj_btn  : '.create-object',
                update_obj_btn  : '.update-object',
                fields_list     : [
                    'id', 'ar_age_from', 'en_age_from', 'ar_age_to', 'en_age_to'
                ],
                imgs_fields     : []
            },
            [
                { data: 'id',           name: 'id' },
                { data: 'ar_age_from',  name: 'ar_age_from' },
                { data: 'en_age_from',  name: 'en_age_from' },
                { data: 'ar_age_to',    name: 'ar_age_to' },
                { data: 'en_age_to',    name: 'en_age_to' },
                { data: 'activation',   name: 'activation' },
                { data: 'actions',      name: 'actions' },
            ],
            function (d) {

                if ($('#s-age_from').length)
                d.age_from = $('#s-age_from').val(); 
            
                if ($('#s-age_to').length)
                d.age_to = $('#s-age_to').val(); 

                if ($('#s-is_active').length)
                d.is_active = $('#s-is_active').val(); 

            }
        );

        objects_dynamic_table.validateData = (data, prefix = '') => {
            // inite validation flag
            let is_valide = true;

            // clear old validation session
            $('.err-msg').slideUp(500);

            if (data.get('ar_age_from') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.ar_age_from_required"); ?>';
                $(`#${prefix}ar_age_fromErr`).text(err_msg);
                $(`#${prefix}ar_age_fromErr`).slideDown(500);
            }

            if (data.get('en_age_from') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.en_age_from_required"); ?>';
                $(`#${prefix}en_age_fromErr`).text(err_msg);
                $(`#${prefix}en_age_fromErr`).slideDown(500);
            }

            if (data.get('ar_age_to') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.ar_age_to_required"); ?>';
                $(`#${prefix}ar_age_toErr`).text(err_msg);
                $(`#${prefix}ar_age_toErr`).slideDown(500);
            }

            if (data.get('en_age_to') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_grades.en_age_to_required"); ?>';
                $(`#${prefix}en_age_toErr`).text(err_msg);
                $(`#${prefix}en_age_toErr`).slideDown(500);
            }

            return is_valide;
        };
    
        objects_dynamic_table.showDataForm = async (targetBtn) => {
        
            let target_user = $(targetBtn).data('object-id');
            let keys = ['ar_age_from', 'en_age_from', 'ar_age_to', 'en_age_to'];
            
            let response = await axios.get(`<?php echo e(url('admin/track-grades')); ?>/${target_user}`);

            let { data, success, msg } = response.data;
            
            if (success) {
                    
                $('#show-ar_age_from').val(data.ar_age_from);
                $('#show-en_age_from').val(data.en_age_from);
                $('#show-ar_age_to').val(data.ar_age_to);
                $('#show-en_age_to').val(data.en_age_to);

                keys.forEach(key => {
                    $(`#show-${key}`).val(data[key]);
                });
                
                return true;
            } else {
                Toastify({
                    text: msg,
                    className: "info",
                    offset: {
                        x: 20, // horizontal axis - can be a number or a string indicating unity. eg: '2em'
                        y: 50 // vertical axis - can be a number or a string indicating unity. eg: '2em'
                    },
                    style: {
                        color: '#842029', background: '#f8d7da', borderColor: '#f5c2c7'
                    }
                }).showToast();
            }

            return false;
        };
            
        objects_dynamic_table.addDataToForm = (fields_id_list, imgs_fields, data, prefix) => {
            fields_id_list.forEach(el_id => {
                $(`#${prefix + el_id}`).val(Boolean(data[el_id]) ? data[el_id] : '').change();
            });
        }
        
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/track_grades/index.blade.php ENDPATH**/ ?>