<?php $__env->startPush('title'); ?>
    <h1 class="h2"><?php echo app('translator')->get('layouts.Track Courses'); ?></h1>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="objectsCard" class="card">
        <div class="card-header">
            <div class="row">
                <div class="col-6 pt-1">
                    <?php echo app('translator')->get('track_courses.Title Adminstration'); ?>
                </div><!-- /.col-6 -->
                <div class="col-6 text-end">
                    
                    <button class="relode-btn btn btn-sm btn-outline-dark">
                        <i class="relode-btn-icon fas fa-sync-alt"></i>
                        <span class="relode-btn-loader spinner-grow spinner-grow-sm" style="display: none;" role="status" aria-hidden="true"></span>
                    </button>

                    <button class="btn btn-sm btn-outline-dark toggle-search">
                        <i class="fas fa-search"></i>
                    </button>

                    <?php if($permissions == 'admin' || in_array('courses_add', $permissions)): ?>
                    <button class="btn btn-sm btn-outline-primary toggle-btn" data-current-card="#objectsCard" data-target-card="#createObjectCard">
                        <i class="fas fa-plus"></i>
                    </button>
                    <?php endif; ?>
                </div><!-- /.col-6 -->
            </div><!-- /.row -->
        </div><!-- /.card-header -->

        
        <div class="card-body custome-table">
            <?php echo $__env->make('admin.track_courses.incs._search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <table id="dataTable" class="table text-center">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo app('translator')->get('track_courses.Title'); ?></th>
                        <th><?php echo app('translator')->get('track_courses.Track'); ?></th>
                        <th><?php echo app('translator')->get('track_courses.Grade'); ?></th>
                        <th><?php echo app('translator')->get('track_courses.Order'); ?></th>
                        <th><?php echo app('translator')->get('track_courses.Groups'); ?></th>
                        <th><?php echo app('translator')->get('track_courses.Subscribers'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Active'); ?></th>
                        <th><?php echo app('translator')->get('layouts.Actions'); ?></th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div><!-- /.card-body -->
    </div><!-- /.card -->

    <?php if($permissions == 'admin' || in_array('tracks_add', $permissions)): ?>
        <?php echo $__env->make('admin.track_courses.incs._create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('tracks_show', $permissions)): ?>
        <?php echo $__env->make('admin.track_courses.incs._show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    
    <?php if($permissions == 'admin' || in_array('tracks_edit', $permissions)): ?>
        <?php echo $__env->make('admin.track_courses.incs._edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custome-js'); ?>
<script>
    $('document').ready(function () {
        let lang = "<?php echo e($lang); ?>";

        const objects_dynamic_table = new DynamicTable(
            {
                index_route   : "<?php echo e(route('admin.trackCourses.index')); ?>",
                store_route   : "<?php echo e(route('admin.trackCourses.store')); ?>",
                show_route    : "<?php echo e(route('admin.trackCourses.index')); ?>",
                update_route  : "<?php echo e(route('admin.trackCourses.index')); ?>",
                destroy_route : "<?php echo e(route('admin.trackCourses.index')); ?>",
            },
            '#dataTable',
            {
                success_el : '#successAlert',
                danger_el  : '#dangerAlert',
                warning_el : '#warningAlert'
            },
            {
                table_id        : '#dataTable',
                toggle_btn      : '.toggle-btn',
                create_obj_btn  : '.create-object',
                update_obj_btn  : '.update-object',
                fields_list     : [
                    'id',
                    'ar_title', 'en_title', 'ar_description', 'en_description', 
                    'track_id', 'order', 'cover' , 'number_of_sessions'
                ],
                imgs_fields     : ['cover']
            },
            [
                { data: 'id',           name: 'id' },
                { data: 'title',        name: 'title' },
                { data: 'track',        name: 'track' },
                { data: 'grade',        name: 'grade' },
                { data: 'order',        name: 'order' },
                { data: 'groups',       name: 'groups' },
                { data: 'subscribers',  name: 'subscribers' },
                { data: 'activation',   name: 'activation' },
                { data: 'actions',      name: 'actions' },
            ],
            function (d) {
                if ($('#s-name').length)
                d.name = $('#s-name').val(); 

                if ($('#s-trainers').length)
                d.trainers = $('#s-trainers').val();  
                
                if ($('#s-categories').length)
                d.categories = $('#s-categories').val();  

                if ($('#s-grades').length)
                d.grades = $('#s-grades').val();  
                
                if ($('#s-is_active').length)
                d.is_active = $('#s-is_active').val(); 
            }
        );

        objects_dynamic_table.validateData = (data, prefix = '') => {
            // inite validation flag
            let is_valide = true;

            // clear old validation session
            $('.err-msg').slideUp(500);

            if (data.get('ar_title') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.ar_title is required"); ?>';
                $(`#${prefix}ar_titleErr`).text(err_msg);
                $(`#${prefix}ar_titleErr`).slideDown(500);
            }

            if (data.get('en_title') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.en_title is required"); ?>';
                $(`#${prefix}en_titleErr`).text(err_msg);
                $(`#${prefix}en_titleErr`).slideDown(500);
            }

            if (data.get('ar_description') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.ar_description is required"); ?>';
                $(`#${prefix}ar_descriptionErr`).text(err_msg);
                $(`#${prefix}ar_descriptionErr`).slideDown(500);
            }

            if (data.get('en_description') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.en_description is required"); ?>';
                $(`#${prefix}en_descriptionErr`).text(err_msg);
                $(`#${prefix}en_descriptionErr`).slideDown(500);
            }

            if (['', 'null', null, 'undefined'].includes(data.get('track_id'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.track_id is required"); ?>';
                $(`#${prefix}track_idErr`).text(err_msg);
                $(`#${prefix}track_idErr`).slideDown(500);
            }

            if (data.get('order') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.order_is_required"); ?>';
                $(`#${prefix}orderErr`).text(err_msg);
                $(`#${prefix}orderErr`).slideDown(500);
            }

            if (data.get('number_of_sessions') === '') {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.number_of_sessions_is_required"); ?>';
                $(`#${prefix}number_of_sessionsErr`).text(err_msg);
                $(`#${prefix}number_of_sessionsErr`).slideDown(500);
            }

            if (prefix == '' && ['', 'undefined'].includes(data.get('cover'))) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.cover_is_required"); ?>';
                $(`#${prefix}coverErr`).text(err_msg); // Corrected line
                $(`#${prefix}coverErr`).slideDown(500); // Corrected line
            }

            if (['', 'undefined'].includes(data.get('cover'))) {
                data.delete('cover');
            }

            if (prefix == '' && Boolean(data.get('cover')) && ($(`#cover`).get(0).files[0].size / (10 ** 6)) > 10) {
                is_valide = false;
                let err_msg = '<?php echo app('translator')->get("track_courses.max_file_size"); ?>';
                $(`#${prefix}coverErr`).text(err_msg); // Corrected line
                $(`#${prefix}coverErr`).slideDown(500); // Corrected line
            }

            return is_valide;
        };

        objects_dynamic_table.showDataForm = async (targetBtn) => {
        
            let target_user = $(targetBtn).data('object-id');
            let keys = ['ar_title', 'en_title', 'ar_description', 'en_description', 'order', 'number_of_sessions'];
            
            let response = await axios.get(`<?php echo e(url('admin/track-courses')); ?>/${target_user}`);

            let { data, success } = response.data;
            console.log(data.track, data.track.grade);
            
            if (success) {
                keys.forEach(key => {
                    $(`#show-${key}`).text(Boolean(data[key]) ? data[key] : '---');
                });

                $('#show-track').html(Boolean(data.track) ? (lang == 'ar' ? data.track.ar_title : data.track.en_title) : '---');
                $('#show-grade').html(Boolean(data.track?.grade) ? (lang == 'ar' ? data.track.grade.ar_title : data.track.grade.en_title) : '---');

                $('#show-cover').attr('src', Boolean(data.cover) ? `<?php echo e(url('/')); ?>/${data.cover}` : '');

                return true;
            }

            return false;
        };
        
        objects_dynamic_table.addDataToForm = (fields_id_list, imgs_fields, data, prefix) => {
            $('#edit-track_grade_id').empty().trigger('change');
            
            $('#edit-id').val(data.id);

            $('#origin-order').val(Boolean(data.order) ? data.order : '');
            $('#origin-track_id').val(Boolean(data.track?.id) ? data.track.id : '');
            
            fields_id_list.forEach(el_id => {
                if (['ar_title', 'en_title', 'ar_description', 'en_description', 'order', 'number_of_sessions'].includes(el_id)) {
                    $(`#${prefix + el_id}`).val(data[el_id]).change();
                }
            });
            
            if(Boolean(data.track?.grade)) {
                let tmp = new Option(lang == 'ar' ? data.track.grade.ar_title : data.track.grade.en_title, data.track.grade.id, false, true);
                $('#edit-grade_id').append(tmp);
                $('#edit-grade_id').removeAttr('disabled').trigger('change');
            }  

            if(Boolean(data.track)) {
                let tmp = new Option(lang == 'ar' ? data.track.ar_title : data.track.en_title, data.track.id, false, true);
                $('#edit-track_id').append(tmp);
                $('#edit-track_id').removeAttr('disabled').trigger('change');
            }
        };

        const init = (() => {
            let lang = "<?php echo e($lang); ?>";
            
            $('#categories, #edit-categories, #s-categories').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Course_Category'); ?>",
                ajax: {
                    url: '<?php echo e(url("admin/course-categories-search")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: $.map(data, function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_name : item.en_name,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

            $('#grade_id, #edit-grade_id, #s-grades').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Grade'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.grades")); ?>',
                    dataType: 'json',
                    delay: 150,
                    processResults: function (data) {
                        return {
                            results: data.map(function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title ,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            }).change(function () {
                window.grade_id = $(this).val(); 
                let target = $(this).data('target');
                
                if (window.grade_id != null) {
                    target == '#edit-track_id' 
                        ? $(target).removeAttr('disabled')
                        : $(target).val('').removeAttr('disabled').trigger('change');
                } else {
                    $(target).val('').attr('disabled', 'disabled').trigger('change');
                }
            });

            $('#track_id, #edit-track_id, #s-grades').select2({
                allowClear: true,
                width: '100%',
                placeholder: "<?php echo app('translator')->get('layouts.Select_Track'); ?>",
                ajax: {
                    url: '<?php echo e(route("admin.search.tracks")); ?>',
                    dataType: 'json',
                    delay: 150,
                    data: function (params) {
                        var query = {
                            q  : params.term,
                            is_sub  : true, 
                            grade_id : window.grade_id
                        }
                        return query;
                    },
                    processResults: function (data) {
                        return {
                            results: data.map(function (item) {
                                return {
                                    text : lang == 'ar' ? item.ar_title : item.en_title ,
                                    id   : item.id
                                }
                            })
                        };
                    },
                    cache: true
                }
            });

        })();
        
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bola\New edu dashboard\Edu_Dashboard\resources\views/admin/track_courses/index.blade.php ENDPATH**/ ?>