<?php
return [
    'sound_link' => 'رابط الصوت',
    'spotify_link' => 'رابط Spotify',
    'tiktok_link' => 'رابط TikTok',
    'youtube_link' => 'رابط YouTube',
    'Create Title' => 'إنشاء عنوان',
    'Ar Title' => 'العنوان بالعربية',
    'En Title' => 'العنوان بالإنجليزية',
    'Image' => 'الصورة',
    'Select Category' => 'اختر الفئة',
    'location' => 'الموقع',
    'price' => 'السعر',
    'start_date' => 'تاريخ البدء',
    'Festivals' => 'المهرجانات',
    'Festival Administration' => 'إدارة المهرجانات',
];
