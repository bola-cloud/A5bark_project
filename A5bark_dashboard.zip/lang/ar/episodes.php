<?php 
return[
    'Ar Title' => 'العنوان بالعربية',
    'En Title' => 'العنوان بالإنجليزية',
    'Ar description' => 'الوصف بالعربية',
    'En description' => 'الوصف بالإنجليزية',
    'number' => 'الرقم',
    'time' => 'الوقت',
    'playlist' => 'القائمة',
    'Title Adminstration'=> 'ادارة الحلقات'
];