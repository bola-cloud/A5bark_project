<?php

return [
    
    'Title Adminstration' => 'Wallets Adminstration',
    
    // Table
    'Name'                    => 'Name',
    'Phone'                   => 'Phone',
    'Email'                   => 'Email',
    'Category'                => 'Category',
    'Valied Balance'          => 'Valied Balance',
    'Pendding Balance'        => 'Pendding Balance',
    'Edit_Valied_Balance'     => 'Edit Valied Balance',
    'Edit_Pendding_Balance'   => 'Edit Pendding Balance',
    'Valied_Balance'          => 'Valied Balance',
    'Pendding_Balance'        => 'Pendding Balance',
    'Update_Valied_Balance'   => 'Update Valide Balance',
    'Update_Pendding_Balance' => 'Update Pendding Balance',

    // Create User 

    // Messages

    // Validation

    // Messages
    'object_created'    => 'You added new workshop employee',
    'object_updated'    => 'You updated workshop employee account',
    'object_deleted'    => 'you deleted workshop employee account',
    'object_not_found'  => 'Workshop employee account not found',
    ''
];