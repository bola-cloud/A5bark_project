<?php
return [
    'sound_link' => 'Sound Link',
    'spotify_link' => 'Spotify Link',
    'tiktok_link' => 'TikTok Link',
    'youtube_link' => 'YouTube Link',
    'Create Title' => 'Create Title',
    'Ar Title' => 'Arabic Title',
    'En Title' => 'English Title',
    'Image' => 'Image',
    'Select Category' => 'Select Category',
    'location' => 'Location',
    'price' => 'Price',
    'start_date' => 'Start Date',
    'Festivals' => 'Festivals',
    'Festival Administration' => 'Festival Administration',
];
