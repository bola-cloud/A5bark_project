<?php 
return[
    'Ar Title' => 'Arabic Title',
    'En Title' => 'English Title',
    'Ar description' => 'Arabic Description',
    'En description' => 'English Description',
    'number' => 'Number',
    'time' => 'Time',
    'playlist' => 'Playlist',
    'Title Adminstration'=> 'Episode Adminstration'
];