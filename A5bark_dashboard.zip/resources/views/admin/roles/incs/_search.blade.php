
<!-- START SEARCH BAR -->
<div style="display: none" class="search-container row mb-2">
    <div class="col-6">
        <div class="my-2 search-action">
            <label for="">@lang('roles.Name')</label>
            <input type="text" class="form-control" id="s-name">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    {{--    
    <div class="col-6">
        <div class="my-2 search-action">
            <label for="">@lang('roles.Users')</label>
            <input type="text" class="form-control" id="s-users">
        </div><!-- /.my-2 -->
    </div><!-- /.col-6 -->

    <div class="col-4">
        <div class="my-2 search-action">
            <label for="">@lang('users.Roles')</label>
            <select type="text" class="form-control" id="s-roles" multiple="multiple">
            </select>
        </div><!-- /.my-2 -->
    </div><!-- /.col-4 -->
    --}}

</div><!-- /.row --> 
<!-- END   SEARCH BAR -->