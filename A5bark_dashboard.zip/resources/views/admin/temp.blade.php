@extends('layouts.admin.app')

@push('title')
    <h1 class="h2 my-2">Dashboard</h1>
@endpush

@section('content')
    <h3>Content ...</h3>
@endsection