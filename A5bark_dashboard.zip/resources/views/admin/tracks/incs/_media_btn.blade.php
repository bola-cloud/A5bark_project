<div class="text-center">
    <button class="update-content btn btn-sm btn-warning" data-target="{{ $row_object->id }}">
        <i class="far fa-file-video"></i>
    </button>
</div>