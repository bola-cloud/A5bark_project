import './bootstrap';
import './magicTable';

console.log('Start test');

// window.Echo.private(`truckerManager.17`)
// .subscribed(() => {
//     console.log('Start Private chat channel subscribe')
// })
// .listen('.truckerTracker', (e) => {
//     console.log('New message : ', e);
// });


// window.Echo.private(`TruckingOffer.117`)
// .subscribed(() => {
//     console.log('Subscribe for reciveing new trucking offers 117')
// })
// .listen('.recivingTruckingOffers', (e) => {
//     console.log('New message : ', e);
// });


// window.Echo.private('TruckingTrip.1')
// .subscribed(() => {
//     console.log('Subscribe for Order location 1')
// })
// .listen('.truckingTrip', (e) => {
//     console.log('Order Location : ', e);
// });
