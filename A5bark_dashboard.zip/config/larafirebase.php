<?php

return [

    'authentication_key' => env('FCM_SERVER_KEY', null),
    'workshop_manager_authentication_key' => env('WORKSHOP_MANAGER_FCM_SERVER_KEY', null),

];
